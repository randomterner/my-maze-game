from flask import Flask, render_template, request
from flask_socketio import SocketIO, emit
import random
import copy
import secrets
import json
from pathlib import Path

app = Flask(__name__)
app.config["SECRET_KEY"] = "maze-secret-key"
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode="threading",
    ping_interval=25,
    ping_timeout=90,
)

BOARD_SIZE = 10

TILE_TYPES = {
    "empty",
    "treasure",
    "fake_treasure",
    "exit",
    "river",
    "river_start",
    "boat",
    "raft",
    "clinic",
    "er",
    "monster",
    "devil",
    "black_hole",
    "flashlight",
    "batteries",
    "armory",
}

# All of these tiles are required exactly once before a game can begin.
# Empty tiles and the river are the only repeatable board tiles.  A river_start
# is part of the river, but has its own one-start rule in river_validation().
REQUIRED_SINGLE_TILES = TILE_TYPES - {"empty", "river", "river_start"}

PICKUP_TILES = {
    "treasure",
    "fake_treasure",
    "boat",
    "raft",
    "flashlight",
    "batteries",
}

DIRECTIONS = {
    "up": (0, -1),
    "down": (0, 1),
    "left": (-1, 0),
    "right": (1, 0),
}

MANAGER_SID = None
MANAGER_RECONNECT_TOKEN = None
DEFAULT_PLAYER_COLOR = "#55e4ff"


def normalize_player_color(value):
    if isinstance(value, str) and len(value) == 7 and value.startswith("#"):
        hex_digits = value[1:]
        if all(char in "0123456789abcdefABCDEF" for char in hex_digits):
            return f"#{hex_digits.lower()}"
    return DEFAULT_PLAYER_COLOR


def new_game_state():
    return {
        "board": {(x, y): "empty" for y in range(BOARD_SIZE) for x in range(BOARD_SIZE)},
        "consumed_tiles": set(),
        "dropped_items": {},
        "inner_walls": set(),
        "broken_walls": set(),
        "players": {},
        "player_order": [],
        "current_turn_index": 0,
        "game_started": False,
        "board_ready": False,
        "game_over": False,
        "winner_sid": None,
        "winner_reason": "",
        "turn_number": 1,
        "logs": [],
        "pending_black_hole": None,
        "pending_treasure": None,
        "treasure_queue": [],
        "start_turn_after_treasure": False,
        "river_lost_map": {
            "tiles": {},
            "open_edges": [],
            "broken_walls": [],
            "wall_edges": [],
        },
        "public_revealed_positions": {},
        "pending_reconnect_claims": {},
        "next_fusion_group_id": 1,
    }


GAME = new_game_state()


def log(message: str):
    GAME["logs"].append(message)


def in_bounds(x, y):
    return 0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE


def is_edge_tile(x, y):
    return x == 0 or y == 0 or x == BOARD_SIZE - 1 or y == BOARD_SIZE - 1


def edge_key(a, b):
    return tuple(sorted([a, b]))


def serialize_edge(a, b):
    e = edge_key(a, b)
    return [list(e[0]), list(e[1])]


def remember_open_edge(player, a, b):
    edge = serialize_edge(a, b)
    if edge not in player["known_open_edges"]:
        player["known_open_edges"].append(edge)
    if edge in player["manual_wall_edges"]:
        player["manual_wall_edges"].remove(edge)


def remember_broken_wall(player, a, b):
    edge = serialize_edge(a, b)
    if edge not in player["known_broken_walls"]:
        player["known_broken_walls"].append(edge)
    if edge in player["manual_wall_edges"]:
        player["manual_wall_edges"].remove(edge)


def remember_wall_edge(player, a, b):
    edge = serialize_edge(a, b)
    if edge not in player["known_wall_edges"]:
        player["known_wall_edges"].append(edge)
    if edge in player["manual_wall_edges"]:
        player["manual_wall_edges"].remove(edge)


def remember_visited_tile(player, pos):
    key = f"{pos[0]},{pos[1]}"
    if key not in player["visited_tiles"]:
        player["visited_tiles"].append(key)


def add_confirmed_map_tile(player, pos, tile):
    """Add automatic map information and count it as a visit while oriented."""
    if not in_bounds(*pos):
        return
    key = f"{pos[0]},{pos[1]}"
    player["known_tiles"][key] = tile
    player["manual_tiles"].pop(key, None)
    if not player.get("lost"):
        remember_visited_tile(player, pos)


def lost_relative_position_for(player, actual_pos):
    """Convert a server-only board position into the lost map's coordinates."""
    return (
        player["lost_relative_x"] + actual_pos[0] - player["x"],
        player["lost_relative_y"] + actual_pos[1] - player["y"],
    )


def remember_lost_edge(player, field, actual_a, actual_b):
    relative_a = lost_relative_position_for(player, actual_a)
    relative_b = lost_relative_position_for(player, actual_b)
    edge = serialize_edge(relative_a, relative_b)
    if edge not in player[field]:
        player[field].append(edge)
    if edge in player["lost_manual_wall_edges"]:
        player["lost_manual_wall_edges"].remove(edge)
    if player.get("lost_kind") == "river":
        river_field = {
            "lost_known_open_edges": "open_edges",
            "lost_known_broken_walls": "broken_walls",
            "lost_known_wall_edges": "wall_edges",
        }.get(field)
        if river_field and edge not in GAME["river_lost_map"][river_field]:
            GAME["river_lost_map"][river_field].append(copy.deepcopy(edge))
            sync_river_lost_map_to_known_players()


def remember_lost_outer_wall_bomb(player, direction):
    """Record a bomb-confirmed outer edge without exposing normal coordinates."""
    x, y = player["x"], player["y"]
    dx, dy = DIRECTIONS[direction]
    remember_lost_edge(player, "lost_known_wall_edges", (x, y), (x + dx, y + dy))

    relative_key = f"{player['lost_relative_x']},{player['lost_relative_y']}"
    clues = player["lost_outer_wall_bomb_clues"].setdefault(relative_key, [])
    if direction not in clues:
        clues.append(direction)


def lost_outer_wall_axes(player):
    """Return which absolute axes the player has anchored with bomb attempts."""
    directions = {
        direction
        for clues in player.get("lost_outer_wall_bomb_clues", {}).values()
        for direction in clues
    }
    return {
        "x": bool(directions & {"left", "right"}),
        "y": bool(directions & {"up", "down"}),
    }


def lost_map_bounds(player):
    """Only disclose the axis established by a bomb-confirmed outer wall."""
    bounds = {"x": None, "y": None}
    for key, directions in player["lost_outer_wall_bomb_clues"].items():
        x, y = map(int, key.split(","))
        for direction in directions:
            if direction in {"left", "right"}:
                bounds["x"] = x if direction == "left" else x - BOARD_SIZE + 1
            else:
                bounds["y"] = y if direction == "up" else y - BOARD_SIZE + 1
    return bounds


def map_completion_progress(player):
    tiles = player["lost_known_tiles"] if player["lost"] else player["known_tiles"]
    points = [tuple(map(int, key.split(","))) for key in tiles]
    axes = lost_outer_wall_axes(player) if player["lost"] else {"x": False, "y": False}
    return {
        "columns": BOARD_SIZE if axes["x"] else min(BOARD_SIZE, len({x for x, _ in points})),
        "rows": BOARD_SIZE if axes["y"] else min(BOARD_SIZE, len({y for _, y in points})),
    }


def lost_map_completion_message(player, known_x, known_y):
    """Apply the 10x10 escape rule, including information from outer-wall bombs."""
    has_all_columns = len(known_x) >= BOARD_SIZE
    has_all_rows = len(known_y) >= BOARD_SIZE
    axes = lost_outer_wall_axes(player)

    if has_all_columns and has_all_rows:
        return "You mapped all 10 relative rows and columns and are no longer lost."
    if axes["x"] and axes["y"]:
        return "Outer-wall bomb hits fixed both map axes, so you are no longer lost."
    if axes["y"] and has_all_columns:
        return "A north/south outer edge and 10 mapped columns revealed your position. You are no longer lost."
    if axes["x"] and has_all_rows:
        return "An east/west outer edge and 10 mapped rows revealed your position. You are no longer lost."
    return None


def reveal_players_at_lost_special_tile(player, pos):
    """Show players who previously found this special tile, in relative space."""
    tile_key = f"{pos[0]},{pos[1]}"
    for other in GAME["players"].values():
        if (
            other["sid"] == player["sid"]
            or not other["alive"]
            or other["lost"]
            or other["x"] is None
            or other["y"] is None
            or tile_key not in other["visited_tiles"]
        ):
            continue

        relative_other = lost_relative_position_for(player, (other["x"], other["y"]))
        relative_key = f"{relative_other[0]},{relative_other[1]}"
        player["lost_known_players"].setdefault(relative_key, [])
        if not any(item["sid"] == other["sid"] for item in player["lost_known_players"][relative_key]):
            player["lost_known_players"][relative_key].append({
                "sid": other["sid"],
                "name": other["name"],
                "color": other.get("color", DEFAULT_PLAYER_COLOR),
            })


def check_lost_map_completion(player):
    tiles = player["lost_known_tiles"] if player["lost"] else player["known_tiles"]
    coordinates = [
        tuple(int(value) for value in key.split(","))
        for key in tiles
    ]
    if not coordinates:
        return False

    known_x = {x for x, _ in coordinates}
    known_y = {y for _, y in coordinates}
    if player["lost"]:
        message = lost_map_completion_message(player, known_x, known_y)
        if message:
            share_lost_section_with_everyone(player)
            recover_from_lost(
                player,
                message,
                reveal_position_to_everyone=True,
            )
            return True
    elif len(known_x) >= BOARD_SIZE and len(known_y) >= BOARD_SIZE:
        share_current_section_with_everyone(player)
        reveal_player_position_to_everyone(player)
        return True
    return False


def remember_lost_tile(player, pos, source="revealed"):
    relative_pos = lost_relative_position_for(player, pos)
    key = f"{relative_pos[0]},{relative_pos[1]}"
    is_new = key not in player["lost_known_tiles"]
    player["lost_known_tiles"][key] = effective_tile_at(pos)
    player["lost_manual_tiles"].pop(key, None)

    if player.get("lost_kind") == "river":
        GAME["river_lost_map"]["tiles"][key] = effective_tile_at(pos)
        sync_river_lost_map_to_known_players()

    # A flashlight can reveal a special tile that is already drawn on the
    # persistent river map.  It still counts as discovering that tile now.
    if tile_allows_map_fusion(pos) or GAME["board"].get(pos) == "river_start":
        reveal_players_at_lost_special_tile(player, pos)

    log_special_tile_reveal(player, pos, source)

    discover_lost_birth_tile(player, pos)
    check_lost_map_completion(player)
    return is_new


def discover_lost_birth_tile(player, pos):
    """Anchor another player's map to a birth tile in this lost section."""
    if not player["lost"]:
        return
    for owner in GAME["players"].values():
        if (
            owner["sid"] == player["sid"]
            or not owner["alive"] or owner["lost"]
            or None in (owner["x"], owner["y"])
            or pos != (owner["birth_x"], owner["birth_y"])
        ):
            continue
        if owner["sid"] not in player["lost_birth_map_sources"]:
            player["lost_birth_map_sources"].append(owner["sid"])
            log(f"{player['name']} linked a relative map through the birth spot of {owner['name']}.")
    sync_lost_birth_maps(player)


def sync_lost_birth_maps(player):
    """Copy confirmed maps in relative space; keep notes and coordinates private."""
    if not player["lost"]:
        return
    familiar_position = None
    for source_sid in player["lost_birth_map_sources"]:
        owner = GAME["players"].get(source_sid)
        for key in list(player["lost_known_players"]):
            player["lost_known_players"][key] = [
                entry for entry in player["lost_known_players"][key]
                if entry["sid"] != source_sid
            ]
            if not player["lost_known_players"][key]:
                del player["lost_known_players"][key]
        if not owner or not owner["alive"] or owner["lost"] or None in (owner["x"], owner["y"]):
            continue
        for key, tile in owner["known_tiles"].items():
            actual = tuple(int(value) for value in key.split(","))
            relative = lost_relative_position_for(player, actual)
            relative_key = f"{relative[0]},{relative[1]}"
            if (
                relative_key not in player["lost_known_tiles"]
                and previously_known_tile_ends_lost(player, actual)
                and GAME["board"].get(actual) not in {"empty", "river", "river_start"}
            ):
                familiar_position = actual
            player["lost_known_tiles"].setdefault(relative_key, tile)
            player["lost_manual_tiles"].pop(relative_key, None)
        for field in ("known_open_edges", "known_broken_walls", "known_wall_edges"):
            for edge in owner[field]:
                relative = serialize_edge(
                    lost_relative_position_for(player, tuple(edge[0])),
                    lost_relative_position_for(player, tuple(edge[1])),
                )
                append_unique_edge(player["lost_" + field], relative)
        relative = lost_relative_position_for(player, (owner["x"], owner["y"]))
        key = f"{relative[0]},{relative[1]}"
        player["lost_known_players"].setdefault(key, []).append({
            "sid": owner["sid"], "name": owner["name"],
            "color": owner.get("color", DEFAULT_PLAYER_COLOR),
        })
    if player.get("lost_kind") == "river":
        GAME["river_lost_map"]["tiles"].update(player["lost_known_tiles"])
        for field, river_field in (("known_open_edges", "open_edges"), ("known_broken_walls", "broken_walls"), ("known_wall_edges", "wall_edges")):
            for edge in player["lost_" + field]:
                append_unique_edge(GAME["river_lost_map"][river_field], edge)
    if familiar_position is not None:
        check_previously_known_recovery(player, familiar_position)


def start_lost_relative_map(player):
    """Start at 0,0; river loss also restores the persistent shared river map."""
    player["lost_relative_x"] = 0
    player["lost_relative_y"] = 0
    if player.get("lost_kind") == "river":
        player["river_processed_tiles"] = list(GAME["river_lost_map"]["tiles"])
        player["lost_known_tiles"] = copy.deepcopy(GAME["river_lost_map"]["tiles"])
        player["lost_known_open_edges"] = copy.deepcopy(GAME["river_lost_map"]["open_edges"])
        player["lost_known_broken_walls"] = copy.deepcopy(GAME["river_lost_map"]["broken_walls"])
        player["lost_known_wall_edges"] = copy.deepcopy(GAME["river_lost_map"]["wall_edges"])
    else:
        player["lost_known_tiles"] = {}
        player["lost_known_open_edges"] = []
        player["lost_known_broken_walls"] = []
        player["lost_known_wall_edges"] = []
    player["lost_known_players"] = {}
    player["lost_manual_tiles"] = {}
    player["lost_manual_wall_edges"] = []
    player["lost_river_players"] = {}
    player["lost_outer_wall_bomb_clues"] = {}
    if player["x"] is not None and player["y"] is not None:
        remember_lost_tile(player, (player["x"], player["y"]))


def player_knows_river_start(player):
    """Whether this player's confirmed map is anchored to the river start."""
    river_start = find_river_start()
    if river_start is None:
        return False
    if player.get("lost"):
        return (
            player.get("lost_kind") == "river"
            and player.get("lost_known_tiles", {}).get("0,0") == "river_start"
        )
    return f"{river_start[0]},{river_start[1]}" in player.get("known_tiles", {})


def sync_river_lost_map_to_player(player):
    """Put the shared river map onto a normal map once its start is known."""
    river_start = find_river_start()
    if player.get("lost") or river_start is None or not player_knows_river_start(player):
        return False

    changed = False

    def actual_position(relative):
        return river_start[0] + relative[0], river_start[1] + relative[1]

    for relative_key, tile in GAME["river_lost_map"]["tiles"].items():
        relative = tuple(int(value) for value in relative_key.split(","))
        actual = actual_position(relative)
        if not in_bounds(*actual):
            continue
        actual_key = f"{actual[0]},{actual[1]}"
        if player["known_tiles"].get(actual_key) != tile:
            changed = True
        add_confirmed_map_tile(player, actual, tile)

    for source_field, target_field in (
        ("open_edges", "known_open_edges"),
        ("broken_walls", "known_broken_walls"),
        ("wall_edges", "known_wall_edges"),
    ):
        for edge in GAME["river_lost_map"][source_field]:
            actual_a = actual_position(tuple(edge[0]))
            actual_b = actual_position(tuple(edge[1]))
            if not in_bounds(*actual_a) or not in_bounds(*actual_b):
                continue
            translated = serialize_edge(actual_a, actual_b)
            if translated not in player[target_field]:
                player[target_field].append(translated)
                changed = True

    return changed


def sync_river_lost_map_to_known_players():
    for player in GAME["players"].values():
        if player.get("alive"):
            sync_river_lost_map_to_player(player)


def resolve_shared_river_discoveries():
    """Shared finds can orient one member without orienting the whole group."""
    start = find_river_start()
    if start is None:
        return
    refresh_lost_river_player_positions()
    anchors_before = [(p, set(p["visited_tiles"])) for p in GAME["players"].values() if p["alive"] and not p["lost"]]
    for player in list(GAME["players"].values()):
        if not player["alive"] or not player["lost"] or player["lost_kind"] != "river":
            continue
        if player.get("map_fusion_blocked_until_turn", 0) > GAME["turn_number"]:
            continue
        for relative_key in list(GAME["river_lost_map"]["tiles"]):
            if relative_key in player["river_processed_tiles"]:
                continue
            player["river_processed_tiles"].append(relative_key)
            rx, ry = map(int, relative_key.split(","))
            pos = (start[0] + rx, start[1] + ry)
            if not in_bounds(*pos):
                continue
            if check_previously_known_recovery(player, pos):
                break
            if is_birth_spot(pos):
                discover_lost_birth_tile(player, pos)
                if not player["lost"]:
                    break
            if GAME["board"].get(pos) in {"empty", "river", "river_start"}:
                continue
            key = f"{pos[0]},{pos[1]}"
            anchors = [p for p, visited in anchors_before if p["sid"] != player["sid"] and key in visited]
            if anchors and not player["lost_birth_map_sources"]:
                recover_from_lost(player, "A shared river discovery matched a known special tile — MAP FUSION!")
                fuse_players_together([player, *anchors])
                break
        if player["lost"]:
            check_lost_map_completion(player)


def reveal_player_position_to_everyone(player):
    """Publish a current location until that player becomes lost again."""
    was_already_public = player["sid"] in GAME["public_revealed_positions"]
    GAME["public_revealed_positions"][player["sid"]] = {
        "sid": player["sid"],
        "name": player["name"],
        "color": player.get("color", DEFAULT_PLAYER_COLOR),
        "x": player["x"],
        "y": player["y"],
    }
    return not was_already_public


def append_unique_edge(target, edge):
    if edge not in target:
        target.append(copy.deepcopy(edge))


def share_map_with_everyone(tiles, open_edges, broken_walls, wall_edges):
    """Add a completed section of map knowledge to every player's normal map."""
    for recipient in GAME["players"].values():
        for key, tile in tiles.items():
            pos = tuple(int(value) for value in key.split(","))
            add_confirmed_map_tile(recipient, pos, tile)
        for edge in open_edges:
            append_unique_edge(recipient["known_open_edges"], edge)
        for edge in broken_walls:
            append_unique_edge(recipient["known_broken_walls"], edge)
        for edge in wall_edges:
            append_unique_edge(recipient["known_wall_edges"], edge)


def share_current_section_with_everyone(player):
    """Share only discoveries made after this player's most recent lost state."""
    previous_tiles = player.get("last_lost_known_tiles", {})
    tiles = {
        key: value for key, value in player["known_tiles"].items()
        if key not in previous_tiles
    }
    share_map_with_everyone(
        tiles,
        player["known_open_edges"],
        player["known_broken_walls"],
        player["known_wall_edges"],
    )


def share_lost_section_with_everyone(player):
    """Share the new section, plus the old section too when the two overlap."""
    previous_tiles = player.get("known_tiles_before_lost", {})
    tiles = {}
    overlaps_previous_section = False

    def actual_position(relative_position):
        return (
            player["x"] + relative_position[0] - player["lost_relative_x"],
            player["y"] + relative_position[1] - player["lost_relative_y"],
        )

    for relative_key, tile in player["lost_known_tiles"].items():
        relative = tuple(int(value) for value in relative_key.split(","))
        actual = actual_position(relative)
        actual_key = f"{actual[0]},{actual[1]}"
        if in_bounds(*actual) and actual_key in previous_tiles:
            overlaps_previous_section = True
        if in_bounds(*actual):
            tiles[actual_key] = tile

    def translate_edges(relative_edges):
        translated = []
        for edge in relative_edges:
            actual_a = actual_position(tuple(edge[0]))
            actual_b = actual_position(tuple(edge[1]))
            key_a = f"{actual_a[0]},{actual_a[1]}"
            key_b = f"{actual_b[0]},{actual_b[1]}"
            if (
                in_bounds(*actual_a)
                and in_bounds(*actual_b)
                and key_a not in previous_tiles
                and key_b not in previous_tiles
            ):
                append_unique_edge(translated, serialize_edge(actual_a, actual_b))
        return translated

    new_open_edges = translate_edges(player["lost_known_open_edges"])
    new_broken_walls = translate_edges(player["lost_known_broken_walls"])
    new_wall_edges = translate_edges(player["lost_known_wall_edges"])

    if overlaps_previous_section:
        tiles = {**previous_tiles, **tiles}
        new_open_edges = [*player.get("known_open_edges_before_lost", []), *new_open_edges]
        new_broken_walls = [*player.get("known_broken_walls_before_lost", []), *new_broken_walls]
        new_wall_edges = [*player.get("known_wall_edges_before_lost", []), *new_wall_edges]

    share_map_with_everyone(tiles, new_open_edges, new_broken_walls, new_wall_edges)
    return overlaps_previous_section


def share_recovered_map_with_linked_players(player):
    """Restore the recovering player's section and share with linked players.

    A player can place this section when they already know the recovery tile,
    or when they previously shared a map-fusion group with the recovered
    player.  The latter means they already know that player's path.
    """
    if player["x"] is None or player["y"] is None:
        return

    recovery_key = f"{player['x']},{player['y']}"
    historical_partners = set(player.get("fusion_history", []))

    def actual_position(relative_position):
        return (
            player["x"] + relative_position[0] - player["lost_relative_x"],
            player["y"] + relative_position[1] - player["lost_relative_y"],
        )

    tiles = {}
    for relative_key, tile in player["lost_known_tiles"].items():
        relative = tuple(int(value) for value in relative_key.split(","))
        actual = actual_position(relative)
        if in_bounds(*actual):
            tiles[f"{actual[0]},{actual[1]}"] = tile

    def translate_edges(relative_edges):
        translated = []
        for edge in relative_edges:
            actual_a = actual_position(tuple(edge[0]))
            actual_b = actual_position(tuple(edge[1]))
            if in_bounds(*actual_a) or in_bounds(*actual_b):
                append_unique_edge(translated, serialize_edge(actual_a, actual_b))
        return translated

    open_edges = translate_edges(player["lost_known_open_edges"])
    broken_walls = translate_edges(player["lost_known_broken_walls"])
    wall_edges = translate_edges(player["lost_known_wall_edges"])
    for recipient in GAME["players"].values():
        if (
            recipient["sid"] != player["sid"]
            and (
                not recipient["alive"]
                or (
                    recovery_key not in recipient["known_tiles"]
                    and recipient["sid"] not in historical_partners
                )
            )
        ):
            continue
        for key, tile in tiles.items():
            pos = tuple(int(value) for value in key.split(","))
            add_confirmed_map_tile(recipient, pos, tile)
        for edge in open_edges:
            append_unique_edge(recipient["known_open_edges"], edge)
        for edge in broken_walls:
            append_unique_edge(recipient["known_broken_walls"], edge)
        for edge in wall_edges:
            append_unique_edge(recipient["known_wall_edges"], edge)


def merge_map_knowledge(receiver, donor):
    for key, value in donor["known_tiles"].items():
        if key not in receiver["known_tiles"]:
            pos = tuple(int(part) for part in key.split(","))
            add_confirmed_map_tile(receiver, pos, value)

    for edge in donor["known_open_edges"]:
        if edge not in receiver["known_open_edges"]:
            receiver["known_open_edges"].append(copy.deepcopy(edge))

    for edge in donor["known_broken_walls"]:
        if edge not in receiver["known_broken_walls"]:
            receiver["known_broken_walls"].append(copy.deepcopy(edge))

    for edge in donor["known_wall_edges"]:
        if edge not in receiver["known_wall_edges"]:
            receiver["known_wall_edges"].append(copy.deepcopy(edge))


def fusion_group_members(group_id):
    return [
        player for player in GAME["players"].values()
        if (
            player["alive"]
            and not player["lost"]
            and player.get("fusion_group") == group_id
        )
    ]


def sync_map_fusion_group(group_id):
    """Keep every active member of one fusion on the same map."""
    members = fusion_group_members(group_id)
    for receiver in members:
        for donor in members:
            if receiver["sid"] != donor["sid"]:
                merge_map_knowledge(receiver, donor)


def sync_all_map_fusion_groups():
    group_ids = {
        player.get("fusion_group") for player in GAME["players"].values()
        if player.get("fusion_group") is not None
    }
    for group_id in group_ids:
        sync_map_fusion_group(group_id)
    sync_saved_fusion_maps()


def sync_saved_fusion_maps():
    """A lost member receives live discoveries on their old, anchored map.

    Partners may receive only the frozen pre-loss section, never the player's
    new relative trail (or discoveries relayed through that trail).
    """
    for lost in GAME["players"].values():
        if not lost["alive"] or not lost["lost"]:
            continue
        frozen = {"known_" + suffix: lost["known_" + suffix + "_before_lost"]
                  for suffix in ("tiles", "open_edges", "broken_walls", "wall_edges")}
        for donor in GAME["players"].values():
            if donor is lost or not donor["alive"] or donor["lost"] or not donor["spawned"]:
                continue
            same_group = lost["fusion_group"] is not None and lost["fusion_group"] == donor["fusion_group"]
            matching_anchor = any(
                key in donor["known_tiles"] and tile_allows_map_fusion(tuple(map(int, key.split(","))))
                for key in frozen["known_tiles"]
            )
            if same_group or matching_anchor:
                merge_map_knowledge(donor, frozen)
                merge_map_knowledge(lost, donor)


def fuse_players_together(players):
    """Join all non-lost participants (and their existing groups) together."""
    participants = [player for player in players if player["alive"] and not player["lost"]]
    if len(participants) < 2:
        return

    old_group_ids = {
        player.get("fusion_group") for player in participants
        if player.get("fusion_group") is not None
    }
    if old_group_ids:
        group_id = min(old_group_ids)
    else:
        group_id = GAME["next_fusion_group_id"]
        GAME["next_fusion_group_id"] += 1

    members = list(participants)
    for candidate in GAME["players"].values():
        if candidate.get("fusion_group") in old_group_ids:
            candidate["fusion_group"] = group_id
            if candidate["alive"] and not candidate["lost"]:
                members.append(candidate)
    for player in participants:
        player["fusion_group"] = group_id

    unique_members = {player["sid"]: player for player in members}.values()
    for first in unique_members:
        for second in unique_members:
            if first["sid"] != second["sid"] and second["sid"] not in first["fusion_history"]:
                first["fusion_history"].append(second["sid"])
    sync_map_fusion_group(group_id)


def dissolve_map_fusion_group(player):
    """Kept for compatibility; losses only hide the lost member temporarily."""
    return


def is_birth_spot(pos):
    for p in GAME["players"].values():
        if p["birth_x"] == pos[0] and p["birth_y"] == pos[1]:
            return True
    return False


def tile_allows_map_fusion(pos):
    tile = GAME["board"].get(pos, "empty")
    return is_birth_spot(pos) or tile not in {"empty", "river", "river_start"}


def is_special_tile(pos):
    """A tile worth announcing when it is revealed.

    River squares are included here because they are meaningful discoveries,
    even though they do not trigger normal special-tile map sharing.
    """
    return GAME["board"].get(pos, "empty") != "empty"


def log_special_tile_reveal(player, pos, source):
    if not is_special_tile(pos):
        return
    tile = GAME["board"].get(pos, "empty")
    log(f"{player['name']} {source} special tile: {tile}.")


def add_special_tile_information_to_map(player, pos):
    """Copy map information supplied by a normally discovered special tile.

    A player who sees a special tile—by stepping on it or by flashlight—has
    made the same discovery.  Other non-lost players who previously visited
    that tile can therefore contribute their map knowledge.  Lost players use
    their relative special-tile map instead, so their hidden location is never
    exposed through this normal-map path.
    """
    if not GAME["game_started"] or player["lost"] or not tile_allows_map_fusion(pos):
        return []

    tile_key = f"{pos[0]},{pos[1]}"
    contributors = []
    for other in GAME["players"].values():
        if (
            other["sid"] == player["sid"]
            or not other["alive"]
            or other["lost"]
            or other["x"] is None
            or other["y"] is None
            or tile_key not in other["visited_tiles"]
        ):
            continue

        merge_map_knowledge(player, other)
        set_relative_player_visibility(player, other)
        contributors.append(other["name"])

    if contributors:
        fuse_players_together([player] + [other for other in GAME["players"].values() if other["name"] in contributors])
        log(
            f"{player['name']} added map information from "
            f"{', '.join(contributors)} through {GAME['board'][pos]}."
        )
    return contributors


def player_is_on_your_map(viewer, other_sid):
    for arr in viewer["known_players"].values():
        for pp in arr:
            if pp["sid"] == other_sid:
                return True
    return False


def set_relative_player_visibility(p1, p2):
    if p1["x"] is None or p1["y"] is None or p2["x"] is None or p2["y"] is None:
        return

    key2 = f"{p2['x']},{p2['y']}"
    p1["known_players"].setdefault(key2, [])
    if not any(pp["sid"] == p2["sid"] for pp in p1["known_players"][key2]):
        p1["known_players"][key2].append({
            "sid": p2["sid"],
            "name": p2["name"],
            "color": p2.get("color", DEFAULT_PLAYER_COLOR),
            "x": p2["x"],
            "y": p2["y"],
        })


def clear_relative_player_visibility(player):
    player["known_players"] = {}


def refresh_known_player_positions():
    """Refresh same-tile, recovered, and active map-fusion player dots."""
    for viewer in GAME["players"].values():
        viewer["known_players"] = {}
        if not viewer["alive"] or viewer["x"] is None or viewer["y"] is None:
            continue

        for other in GAME["players"].values():
            current_key = f"{other['x']},{other['y']}"
            exited_lost_here = (
                other.get("lost_exit_visible_position") == (other["x"], other["y"])
                and current_key in viewer["visited_tiles"]
            )
            sharing_a_fusion_map = (
                not viewer["lost"]
                and not other["lost"]
                and viewer.get("fusion_group") is not None
                and viewer.get("fusion_group") == other.get("fusion_group")
            )
            anchored_by_birth = (
                not viewer["lost"] and other["alive"]
                and viewer["sid"] in other["lost_birth_map_sources"]
            )
            if (
                other["sid"] != viewer["sid"]
                and other["alive"]
                and other["x"] == viewer["x"]
                and other["y"] == viewer["y"]
            ) or (
                other["sid"] != viewer["sid"]
                and other["alive"]
                and exited_lost_here
            ) or sharing_a_fusion_map or anchored_by_birth:
                if other["sid"] == viewer["sid"]:
                    continue
                set_relative_player_visibility(viewer, other)
                if anchored_by_birth:
                    add_known_tile(viewer, (other["x"], other["y"]))


def refresh_lost_river_player_positions():
    """River-lost players share the river-start-relative map with each other."""
    river_lost_players = [
        player for player in GAME["players"].values()
        if player["alive"] and player["lost"] and player.get("lost_kind") == "river"
    ]

    for viewer in river_lost_players:
        viewer["lost_known_tiles"].update(copy.deepcopy(GAME["river_lost_map"]["tiles"]))
        for field, river_field in (("known_open_edges", "open_edges"), ("known_broken_walls", "broken_walls"), ("known_wall_edges", "wall_edges")):
            for edge in GAME["river_lost_map"][river_field]:
                append_unique_edge(viewer["lost_" + field], edge)
        viewer["lost_river_players"] = {}
        for other in river_lost_players:
            if other["sid"] == viewer["sid"]:
                continue
            key = f"{other['lost_relative_x']},{other['lost_relative_y']}"
            viewer["lost_river_players"].setdefault(key, []).append({
                "sid": other["sid"],
                "name": other["name"],
                "color": other.get("color", DEFAULT_PLAYER_COLOR),
            })


def announce_players_on_tile(player):
    """Notify all players when they discover one another on the same tile."""
    companions = [
        other for other in GAME["players"].values()
        if other["sid"] != player["sid"]
        and other["alive"]
        and other["x"] == player["x"]
        and other["y"] == player["y"]
    ]
    if not companions:
        return

    names = ", ".join(other["name"] for other in companions)
    set_player_message(player, f"You found {names}.")
    for other in companions:
        set_player_message(other, f"{player['name']} found you.")
    log(f"{player['name']} found {names}.")


def enter_lost_state(player, lost_kind):
    for other in GAME["players"].values():
        other["lost_fusion_links"] = [sid for sid in other["lost_fusion_links"] if sid != player["sid"]]
    player["lost_fusion_links"] = []
    if player["lost"] and player["lost_known_tiles"]:
        archived = serialize_relative_trail(player)
        archived.pop("relative_position", None)
        archived.update(name="Earlier lost map", players=[], archived=True, absolute=False,
                        id=f"archive-{player['sid']}-{len(player['map_archive'])}", member_sids=[player["sid"]])
        player["map_archive"].append(archived)
    player["lost_birth_map_sources"] = []
    if not player["lost"]:
        player["known_tiles_before_lost"] = copy.deepcopy(player["known_tiles"])
        player["known_open_edges_before_lost"] = copy.deepcopy(player["known_open_edges"])
        player["known_broken_walls_before_lost"] = copy.deepcopy(player["known_broken_walls"])
        player["known_wall_edges_before_lost"] = copy.deepcopy(player["known_wall_edges"])
        player["last_lost_known_tiles"] = copy.deepcopy(player["known_tiles"])
    player["lost"] = True
    player["lost_kind"] = lost_kind
    # A loss must stand on its own before a shared map can affect it.
    player["map_fusion_blocked_until_turn"] = GAME["turn_number"] + 1
    GAME["public_revealed_positions"].pop(player["sid"], None)
    clear_relative_player_visibility(player)


def previously_known_tile_ends_lost(player, pos=None):
    if pos is None:
        if player["x"] is None or player["y"] is None:
            return False
        pos = (player["x"], player["y"])
    if pos is None:
        return False
    if GAME["board"].get(pos, "empty") in {"empty", "river", "river_start"}:
        return False
    key = f"{pos[0]},{pos[1]}"
    return key in player.get("known_tiles_before_lost", {})


def recover_from_lost(player, message, reveal_position_to_everyone=False):
    player["lost"] = False
    player["lost_kind"] = None
    # Anchor the lost section before revealing this position or checking map
    # completion. The recovering player must receive their own discoveries.
    share_recovered_map_with_linked_players(player)
    player["lost_exit_visible_position"] = (player["x"], player["y"])
    reveal_current_position(player)
    player["known_tiles_before_lost"] = {}
    if reveal_position_to_everyone:
        reveal_player_position_to_everyone(player)
    set_player_message(player, message)
    log(f"{player['name']} is no longer lost.")


def activate_map_fusion(player):
    if not GAME["game_started"]:
        return

    if player.get("map_fusion_blocked_until_turn", 0) > GAME["turn_number"]:
        return

    if player["x"] is None or player["y"] is None:
        return

    current_pos = (player["x"], player["y"])
    current_key = f"{player['x']},{player['y']}"
    if player["lost"]:
        peers = [other for other in GAME["players"].values() if other is not player and other["alive"] and other["lost"]
                 and (other["x"], other["y"]) == current_pos
                 and other["map_fusion_blocked_until_turn"] <= GAME["turn_number"]]
        if peers:
            members = {p["sid"] for p in [player, *peers]}
            for p in [player, *peers]:
                members.update(sid for sid in p["lost_fusion_links"] if sid in GAME["players"] and GAME["players"][sid]["lost"] and GAME["players"][sid]["alive"])
            changed = any(set(GAME["players"][sid]["lost_fusion_links"]) != members - {sid} for sid in members)
            for sid in members:
                GAME["players"][sid]["lost_fusion_links"] = sorted(members - {sid})
            if changed:
                log("Lost players met — their relative maps are now shared.")
            sync_lost_fusion_maps()
    meeting = any(other["sid"] != player["sid"] and other["alive"] and not other["lost"]
                  and (other["x"], other["y"]) == current_pos for other in GAME["players"].values())
    if player["lost"] and is_birth_spot(current_pos) and not meeting:
        discover_lost_birth_tile(player, current_pos)
        if player["lost"] and player["lost_birth_map_sources"]:
            return
    if not tile_allows_map_fusion(current_pos) and not meeting:
        return

    same_tile_players = []
    for other in GAME["players"].values():
        if other["sid"] == player["sid"]:
            continue
        if other["x"] is None or other["y"] is None:
            continue
        if other["alive"] and not other["lost"] and other["x"] == player["x"] and other["y"] == player["y"]:
            same_tile_players.append(other)

    if same_tile_players:
        involved = [player] + same_tile_players

        if any(
            candidate.get("map_fusion_blocked_until_turn", 0) > GAME["turn_number"]
            for candidate in involved
        ):
            return

        for a in involved:
            for b in involved:
                if a["sid"] == b["sid"]:
                    continue
                if (a["lost"] and a["lost_birth_map_sources"]) or (b["lost"] and b["lost_birth_map_sources"]):
                    continue
                merge_map_knowledge(a, b)
                set_relative_player_visibility(a, b)

        if player["lost"]:
            # A non-lost participant can anchor a qualifying special tile.
            if (
                any(player_is_on_your_map(player, other["sid"]) for other in same_tile_players)
            ):
                recover_from_lost(player, f"You met {', '.join([p['name'] for p in same_tile_players])} → MAP FUSION!")
        else:
            reveal_current_position(player)
            set_player_message(player, f"You met {', '.join([p['name'] for p in same_tile_players])} → MAP FUSION!")

        for other in same_tile_players:
            if other["lost"]:
                if (
                    tile_allows_map_fusion(current_pos)
                    and not other["lost_birth_map_sources"]
                    and player_is_on_your_map(other, player["sid"])
                ):
                    recover_from_lost(other, f"You met {player['name']} → MAP FUSION!")
            else:
                reveal_current_position(other)
                set_player_message(other, f"You met {player['name']} → MAP FUSION!")

        fuse_players_together(involved)

        if len(involved) == 2:
            log(f"{player['name']} met {same_tile_players[0]['name']} → MAP FUSION")
        else:
            log("MAP FUSION happened between players on the same tile.")
        return

    if not tile_allows_map_fusion(current_pos) and not is_birth_spot(current_pos):
        return

    for other in GAME["players"].values():
        if other["sid"] == player["sid"]:
            continue
        if other["x"] is None or other["y"] is None:
            continue

        if not other["alive"] or other["lost"] or other.get("map_fusion_blocked_until_turn", 0) > GAME["turn_number"]:
            continue

        if current_key in other["visited_tiles"]:
            merge_map_knowledge(player, other)
            set_relative_player_visibility(player, other)

            if player["lost"]:
                if (
                    player_is_on_your_map(player, other["sid"])
                ):
                    recover_from_lost(player, f"You found traces of {other['name']} → MAP FUSION")
                else:
                    set_player_message(player, f"You found traces of {other['name']} → MAP FUSION")
            else:
                reveal_current_position(player)
                set_player_message(player, f"You found traces of {other['name']} → MAP FUSION")
            fuse_players_together([player, other])
            return


def check_birth_spot_discovery(player, announce_visit=True):
    if player["x"] is None or player["y"] is None:
        return False

    owners = [
        other for other in GAME["players"].values()
        if other["birth_x"] is not None
        and other["birth_y"] is not None
        and player["x"] == other["birth_x"]
        and player["y"] == other["birth_y"]
    ]
    if not owners:
        return False

    owner_names = ", ".join(other["name"] for other in owners)
    if announce_visit:
        log(f"{player['name']} visited the birth tile of {owner_names}.")

    if any(other["sid"] == player["sid"] for other in owners):
        if player["lost"]:
            recover_from_lost(player, "You found your birth spot and are no longer lost.")
            return True
        return False

    if len(owners) == 1:
        set_player_message(player, f"You found {owners[0]['name']}'s birth spot.")
    else:
        set_player_message(player, f"You found birth spots belonging to {owner_names}.")
    return False


def check_previously_known_recovery(player, pos=None, discovered_by_flashlight=False):
    if player["lost"] and previously_known_tile_ends_lost(player, pos):
        message = (
            "Your flashlight revealed a familiar tile and you are no longer lost."
            if discovered_by_flashlight
            else "You reached a familiar tile and are no longer lost."
        )
        recover_from_lost(player, message)
        return True
    return False


def is_outer_wall(x, y, direction):
    if direction == "up":
        return y == 0
    if direction == "down":
        return y == BOARD_SIZE - 1
    if direction == "left":
        return x == 0
    if direction == "right":
        return x == BOARD_SIZE - 1
    return False


def has_inner_wall_between(a, b):
    return edge_key(a, b) in GAME["inner_walls"]


def wall_blocks(x, y, direction):
    if is_outer_wall(x, y, direction):
        return True
    dx, dy = DIRECTIONS[direction]
    nx, ny = x + dx, y + dy
    if not in_bounds(nx, ny):
        return True
    return has_inner_wall_between((x, y), (nx, ny))


def alive_players():
    return [p for p in GAME["players"].values() if p["alive"]]


def alive_player_sids_in_order():
    return [
        sid for sid in GAME["player_order"]
        if sid in GAME["players"]
        and GAME["players"][sid]["alive"]
    ]


def current_turn_sid():
    order = alive_player_sids_in_order()
    if not order:
        return None
    if GAME["current_turn_index"] >= len(order):
        GAME["current_turn_index"] = 0
    return order[GAME["current_turn_index"]]


def current_player():
    sid = current_turn_sid()
    if sid is None:
        return None
    return GAME["players"][sid]


def prepare_player_turn(player):
    """Apply once-only start-of-turn work for the active player."""
    if (player["alive"] and player["spawned"] and player["items"]["treasure"]
            and GAME["board"].get((player["x"], player["y"])) == "exit"):
        GAME["game_over"] = True
        GAME["winner_sid"] = player["sid"]
        GAME["winner_reason"] = "treasure_exit"
        set_player_message(player, "You escaped with the real treasure and won!")
        log(f"{player['name']} escaped through the exit with the real treasure.")
        return "game_over"
    if player.get("in_river"):
        pos = (player.get("x"), player.get("y"))
        if pos not in GAME["board"] or GAME["board"][pos] not in {"river", "river_start"}:
            player["in_river"] = False

    if not player.get("spawn_effect_pending"):
        return "continue"

    player["spawn_effect_pending"] = False
    spawn_tile = GAME["board"][(player["x"], player["y"])]
    result = apply_tile_effect(player, "started their first turn on", grant_extra_turn=False)
    if result == "pending_treasure":
        return result
    set_player_message(player, f"Spawned on {spawn_tile}. {player['last_message']}")
    if result not in {"dead", "pending_black_hole"}:
        check_birth_spot_discovery(player, announce_visit=False)
        check_previously_known_recovery(player)
    refresh_known_player_positions()
    return result


def start_current_turn():
    """Run a pending spawn effect, skipping players killed by theirs."""
    player = current_player()
    if player is None:
        return "continue"
    result = prepare_player_turn(player)
    if result == "dead" and not GAME["game_over"]:
        # A dead player leaves the alive order, so this same index now points
        # at the following living player.
        return start_current_turn()
    return result


def all_spawned():
    if len(GAME["players"]) < 2:
        return False
    return all(p["spawned"] for p in GAME["players"].values())


def create_player(sid, name, color=DEFAULT_PLAYER_COLOR):
    return {
        "sid": sid,
        "connected": True,
        "name": name,
        "color": normalize_player_color(color),
        "x": None,
        "y": None,
        "birth_x": None,
        "birth_y": None,
        "alive": True,
        "spawned": False,
        "injuries": 0,
        "bullets": 3,
        "bombs": 3,
        "items": {
            "treasure": False,
            "fake_treasure": False,
            "boat": False,
            "raft": False,
            "flashlight": False,
            "batteries": False,
        },
        "known_tiles": {},
        "manual_tiles": {},
        "manual_wall_edges": [],
        "known_tiles_before_lost": {},
        "map_archive": [],
        "river_processed_tiles": [],
        "known_open_edges_before_lost": [],
        "known_broken_walls_before_lost": [],
        "known_wall_edges_before_lost": [],
        "last_lost_known_tiles": {},
        "known_players": {},
        "known_open_edges": [],
        "known_broken_walls": [],
        "known_wall_edges": [],
        "visited_tiles": [],
        "lost_relative_x": 0,
        "lost_relative_y": 0,
        "lost_known_tiles": {},
        "lost_manual_tiles": {},
        "lost_manual_wall_edges": [],
        "lost_known_players": {},
        "lost_birth_map_sources": [],
        "lost_fusion_links": [],
        "lost_known_open_edges": [],
        "lost_known_broken_walls": [],
        "lost_known_wall_edges": [],
        "lost_river_players": {},
        "lost_outer_wall_bomb_clues": {},
        "lost_kind": None,
        "map_fusion_blocked_until_turn": 0,
        "fusion_group": None,
        "fusion_history": [],
        "in_river": False,
        "lost_exit_visible_position": None,
        "spawn_effect_pending": False,
        "last_message": "Choose a spawn tile by tapping the board.",
        "extra_turn": False,
        "lost": False,
    }


def set_player_message(player, message, shared=True):
    player["last_message"] = message
    if shared:
        # The shared expedition log is the history everyone can see. Keep
        # host/game results there, while player-written notes stay private.
        log(f"{player['name']}: {message}")


def effective_tile_at(pos):
    base = GAME["board"].get(pos, "empty")
    if pos in GAME["consumed_tiles"] and base in PICKUP_TILES:
        return f"used_{base}"
    return base


def add_known_tile(player, pos):
    if not in_bounds(pos[0], pos[1]):
        return
    add_confirmed_map_tile(player, pos, effective_tile_at(pos))


def update_known_players_for_viewer(viewer):
    if not GAME["game_started"]:
        viewer["known_players"] = {}
        return

    preserved_sids = set()
    for arr in viewer["known_players"].values():
        for pp in arr:
            preserved_sids.add(pp["sid"])

    new_map = {}
    for other in GAME["players"].values():
        if not other["alive"] or other["x"] is None or other["y"] is None:
            continue
        if other["sid"] not in preserved_sids:
            continue
        if viewer["lost"] and other["sid"] == viewer["sid"]:
            continue

        key = f"{other['x']},{other['y']}"
        new_map.setdefault(key, [])
        new_map[key].append({
            "sid": other["sid"],
            "name": other["name"],
            "color": other.get("color", DEFAULT_PLAYER_COLOR),
            "x": other["x"],
            "y": other["y"],
        })

    viewer["known_players"] = new_map


def reveal_position(player, pos, source="revealed"):
    add_known_tile(player, pos)
    remember_visited_tile(player, pos)
    log_special_tile_reveal(player, pos, source)
    add_special_tile_information_to_map(player, pos)
    update_known_players_for_viewer(player)
    if not player["lost"]:
        check_lost_map_completion(player)


def reveal_current_position(player, source="revealed"):
    if player["x"] is None or player["y"] is None:
        return
    pos = (player["x"], player["y"])
    if player["lost"]:
        remember_visited_tile(player, pos)
        remember_lost_tile(player, pos, source)
        return
    reveal_position(player, pos, source)


def check_death(player, reason="", check_winner=True):
    if player["alive"] and player["injuries"] >= 5:
        player["alive"] = False
        set_player_message(player, "You died.")
        if reason:
            log(f"{player['name']} died. {reason}")
        else:
            log(f"{player['name']} died.")
        if check_winner:
            check_last_player_win()
        return True
    return False


def check_last_player_win():
    if GAME["game_over"]:
        return
    alive = alive_players()
    if len(alive) == 1 and len(GAME["players"]) >= 2:
        winner = alive[0]
        GAME["game_over"] = True
        GAME["winner_sid"] = winner["sid"]
        GAME["winner_reason"] = "last_player_alive"
        log(f"{winner['name']} wins as the last player alive.")
    elif len(alive) == 0 and len(GAME["players"]) >= 2:
        GAME["game_over"] = True
        GAME["winner_sid"] = None
        GAME["winner_reason"] = "all_players_dead"
        log("All players died. The game ended with no winner.")


def end_turn():
    if GAME["pending_treasure"]:
        GAME["pending_treasure"]["end_turn_requested"] = True
        emit_full_state()
        return
    if GAME["game_over"]:
        emit_full_state()
        return

    player = current_player()
    if player and player["alive"] and player["extra_turn"]:
        player["extra_turn"] = False
        GAME["turn_number"] += 1
        start_current_turn()
        log(f"{player['name']} gets an extra turn.")
        emit_full_state()
        return

    order = alive_player_sids_in_order()
    if not order:
        emit_full_state()
        return

    GAME["current_turn_index"] += 1
    if GAME["current_turn_index"] >= len(order):
        GAME["current_turn_index"] = 0

    GAME["turn_number"] += 1
    start_current_turn()
    emit_full_state()


def reset_game():
    global GAME
    old_players = GAME["players"]
    new_state = new_game_state()
    for sid, old_player in old_players.items():
        new_state["players"][sid] = create_player(
            sid, old_player["name"], old_player.get("color")
        )
    GAME = new_state
    log("Game reset. Connected players were kept.")
    emit_full_state()


def find_river_start():
    starts = [pos for pos, tile in GAME["board"].items() if tile == "river_start"]
    if not starts:
        return None
    return starts[0]


def get_river_positions():
    return {pos for pos, tile in GAME["board"].items() if tile in {"river", "river_start"}}


def river_validation(board=None, inner_walls=None):
    board = GAME["board"] if board is None else board
    inner_walls = GAME["inner_walls"] if inner_walls is None else inner_walls
    river_positions = {pos for pos, tile in board.items() if tile in {"river", "river_start"}}

    if not river_positions:
        return {
            "ok": False,
            "message": "The board needs at least one river tile (river_start counts).",
        }

    if len(river_positions) > 20:
        return {"ok": False, "message": "River may use at most 20 tiles including river_start."}

    river_starts = [pos for pos, tile in board.items() if tile == "river_start"]
    if len(river_starts) != 1:
        return {"ok": False, "message": "River must contain exactly one river_start tile."}

    river_start = river_starts[0]

    # A river may turn a corner. A diagonal pair is invalid only when it is
    # not joined by a river tile on either side of that diagonal.
    for (x, y) in river_positions:
        diagonal_neighbors = [
            (x - 1, y - 1), (x + 1, y - 1),
            (x - 1, y + 1), (x + 1, y + 1),
        ]
        for diagonal in diagonal_neighbors:
            if diagonal not in river_positions:
                continue
            dx, dy = diagonal[0] - x, diagonal[1] - y
            connecting_tiles = [(x + dx, y), (x, y + dy)]
            if not any(pos in river_positions for pos in connecting_tiles):
                return {
                    "ok": False,
                    "message": "Diagonal river tiles must connect through a river tile.",
                }

    orth_neighbors = {}
    for (x, y) in river_positions:
        neighbors = []
        for dx, dy in DIRECTIONS.values():
            nxt = (x + dx, y + dy)
            if nxt in river_positions and edge_key((x, y), nxt) not in inner_walls:
                neighbors.append(nxt)
        orth_neighbors[(x, y)] = neighbors

    for pos, neighbors in orth_neighbors.items():
        if len(neighbors) > 2:
            return {"ok": False, "message": "River cannot split at any point."}

    if len(river_positions) == 1:
        if len(orth_neighbors[river_start]) != 0:
            return {"ok": False, "message": "Single-tile river_start cannot connect to other river tiles."}
    else:
        if len(orth_neighbors[river_start]) != 1:
            return {"ok": False, "message": "river_start must connect to exactly one river tile."}

    stack = [river_start]
    seen = set()

    while stack:
        pos = stack.pop()
        if pos in seen:
            continue
        seen.add(pos)
        for nxt in orth_neighbors[pos]:
            if nxt not in seen:
                stack.append(nxt)

    if seen == river_positions:
        return {"ok": True, "message": "River is valid."}

    return {"ok": False, "message": "All river tiles must be connected."}


def required_tile_validation(board=None):
    """Check the one-of-each-tile rule used when starting a game."""
    board = GAME["board"] if board is None else board
    counts = {
        tile: sum(board_tile == tile for board_tile in board.values())
        for tile in REQUIRED_SINGLE_TILES
    }
    missing = sorted(tile for tile, count in counts.items() if count == 0)
    duplicates = sorted(tile for tile, count in counts.items() if count > 1)

    if missing:
        return {
            "ok": False,
            "message": f"The board is missing: {', '.join(missing)}.",
        }
    if duplicates:
        return {
            "ok": False,
            "message": f"Only one of each is allowed: {', '.join(duplicates)}.",
        }
    return {"ok": True, "message": "All required tile types are placed exactly once."}


def drop_held_items(player):
    pos = (player["x"], player["y"])
    items = [name for name, held in player["items"].items() if held]
    if None not in pos and items:
        ground = GAME["dropped_items"].setdefault(pos, set())
        ground.update(items)
        log(f"{player['name']} dropped: {', '.join(items)}.")
    for name in items:
        player["items"][name] = False


def collect_dropped_items(player):
    pos = (player["x"], player["y"])
    items = GAME["dropped_items"].get(pos, set())
    collected = sorted(name for name in items if not player["items"].get(name))
    for name in collected:
        player["items"][name] = True
        items.remove(name)
    if not items:
        GAME["dropped_items"].pop(pos, None)
    if collected:
        log(f"{player['name']} picked up dropped items: {', '.join(collected)}.")


def handle_pickup(player, pos, tile):
    if pos in GAME["consumed_tiles"]:
        if tile == "treasure":
            return "There was a treasure here."
        if tile == "fake_treasure":
            return "There was a fake treasure here."
        if tile == "boat":
            return "There was a boat here."
        if tile == "raft":
            return "There was a raft here."
        if tile == "flashlight":
            return "There was a flashlight here."
        if tile == "batteries":
            return "There were batteries here."
        return "This item was already taken."

    if tile == "treasure":
        player["items"]["treasure"] = True
        GAME["consumed_tiles"].add(pos)
        log(f"{player['name']} found the real treasure.")
        return "You found the real treasure!"

    if tile == "fake_treasure":
        player["items"]["fake_treasure"] = True
        GAME["consumed_tiles"].add(pos)
        return "You found a fake treasure."

    if tile == "boat":
        player["items"]["boat"] = True
        GAME["consumed_tiles"].add(pos)
        return "You picked up a boat."

    if tile == "raft":
        player["items"]["raft"] = True
        GAME["consumed_tiles"].add(pos)
        return "You picked up a raft."

    if tile == "flashlight":
        player["items"]["flashlight"] = True
        GAME["consumed_tiles"].add(pos)
        return "You picked up a flashlight."

    if tile == "batteries":
        player["items"]["batteries"] = True
        GAME["consumed_tiles"].add(pos)
        return "You picked up batteries."

    return ""


def begin_treasure_reveal(player, pos):
    pending = {"player_sid": player["sid"], "name": player["name"], "phase": "hype",
               "kind": GAME["board"][pos], "end_turn_requested": False, "token": secrets.token_hex(16)}
    GAME["consumed_tiles"].add(pos)
    player["items"][pending["kind"]] = True
    GAME["treasure_queue"].append(pending)
    set_player_message(player, "TREASURE FOUND! Could this be the winning treasure?")
    advance_treasure_queue()


def advance_treasure_queue():
    if GAME["pending_treasure"] or not GAME["treasure_queue"]:
        return
    pending = GAME["treasure_queue"].pop(0)
    GAME["pending_treasure"] = pending
    socketio.start_background_task(reveal_fake_treasure_after_delay, GAME, pending)


def reveal_fake_treasure_after_delay(game, pending):
    socketio.sleep(3)
    finish_fake_treasure_reveal(game, pending)


def finish_fake_treasure_reveal(game, pending):
    if GAME is not game or GAME["pending_treasure"] is not pending:
        return
    player = GAME["players"].get(pending["player_sid"])
    if not player:
        GAME["pending_treasure"] = None
        return
    pending["phase"] = "revealed"
    kind = pending.get("kind", "fake_treasure")
    player["items"][kind] = True
    set_player_message(player, "The treasure is real! Confirm the reveal to continue." if kind == "treasure"
                       else "Plot twist! The treasure is fake. Confirm the reveal to continue.")
    emit_full_state()


def treasure_reveal_state():
    pending = GAME["pending_treasure"]
    if not pending:
        return None
    return {**{key: pending[key] for key in ("player_sid", "name", "phase")},
            "kind": pending.get("kind", "fake_treasure") if pending["phase"] == "revealed" else None}


def mask_treasure_suspense(value):
    """Do not spoil the short reveal through public maps, stats, or logs."""
    if not GAME["pending_treasure"] or GAME["pending_treasure"]["phase"] != "hype":
        return value
    if isinstance(value, str):
        return value.replace("fake_treasure", "treasure").replace("fake treasure", "treasure")
    if isinstance(value, list):
        return [mask_treasure_suspense(item) for item in value]
    if isinstance(value, dict):
        if "treasure" in value and "fake_treasure" in value:
            value = {**value, "treasure": bool(value["treasure"] or value["fake_treasure"]), "fake_treasure": False}
        return {key: mask_treasure_suspense(item) for key, item in value.items()}
    return value


def apply_tile_effect(player, discovery_source="stepped onto", grant_extra_turn=True):
    pos = (player["x"], player["y"])
    raw_tile = GAME["board"][pos]
    collect_dropped_items(player)

    reveal_current_position(player, discovery_source)

    if raw_tile in {"treasure", "fake_treasure"} and pos not in GAME["consumed_tiles"]:
        begin_treasure_reveal(player, pos)
        return "pending_treasure"

    # Being dragged to the river start begins a continuous river journey.
    # River tiles only map the journey until the player steps onto dry land.
    if player.get("in_river") and raw_tile in {"river", "river_start"}:
        set_player_message(player, "You continue along the river.")
        return "continue"

    if raw_tile in PICKUP_TILES:
        set_player_message(player, handle_pickup(player, pos, raw_tile))
        return "continue"

    if raw_tile == "empty":
        set_player_message(player, "Empty tile.")
        return "continue"

    if raw_tile == "exit":
        if player["items"]["treasure"]:
            set_player_message(player, "You reached the exit with the treasure. Survive until your next turn to escape.")
        else:
            set_player_message(player, "You found the exit, but you do not have the real treasure.")
        return "continue"

    if raw_tile == "clinic":
        if 0 < player["injuries"] < 4:
            player["injuries"] = 0
            set_player_message(player, "Clinic healed all of your injuries.")
        elif player["injuries"] == 4:
            set_player_message(player, "Clinic cannot treat 4 injuries. Go to the ER.")
        else:
            set_player_message(player, "Clinic did nothing because you have no injuries.")
        return "continue"

    if raw_tile == "er":
        if player["injuries"] == 4:
            player["injuries"] = 3
            set_player_message(player, "ER reduced your injuries from 4 to 3.")
        else:
            set_player_message(player, "ER did nothing.")
        return "continue"

    if raw_tile == "monster":
        old_bullets = player["bullets"]
        old_bombs = player["bombs"]
        player["bullets"] = min(5, player["bullets"] + 1)
        player["bombs"] = min(5, player["bombs"] + 1)
        if grant_extra_turn:
            player["extra_turn"] = True
        set_player_message(
            player,
            f"Monster: bullets {old_bullets}->{player['bullets']}, bombs {old_bombs}->{player['bombs']}."
            + (" Extra turn granted." if grant_extra_turn else "")
        )
        return "continue"

    if raw_tile == "devil":
        player["injuries"] += 1
        player["bullets"] = max(0, player["bullets"] - 1)
        player["bombs"] = max(0, player["bombs"] - 1)
        if check_death(player, "Killed by devil tile."):
            return "dead"
        set_player_message(player, "Devil: +1 injury, -1 bullet, -1 bomb.")
        return "continue"

    if raw_tile == "black_hole":
        GAME["pending_black_hole"] = {"player_sid": player["sid"]}
        set_player_message(player, "Black hole! Waiting for manager placement.")
        log(f"{player['name']} entered a black hole.")
        return "pending_black_hole"

    if raw_tile == "armory":
        old_bullets = player["bullets"]
        old_bombs = player["bombs"]
        player["bullets"] = max(player["bullets"], 3)
        player["bombs"] = max(player["bombs"], 3)
        set_player_message(
            player,
            f"Armory: bullets {old_bullets}->{player['bullets']}, bombs {old_bombs}->{player['bombs']}."
        )
        return "continue"

    if raw_tile == "river_start":
        player["injuries"] += 1
        if check_death(player, "Killed by river-start injury."):
            return "dead"
        set_player_message(player, "River start: +1 injury, but you stayed oriented.")
        return "continue"

    if raw_tile == "river":
        river_start = find_river_start()
        entered_own_birth_river = pos == (player["birth_x"], player["birth_y"])
        was_lost_before_entering_river = player["lost"]

        if player["items"]["boat"]:
            set_player_message(player, "You crossed the river safely with the boat.")
            return "continue"

        if player["items"]["raft"]:
            if river_start is not None:
                river_start_key = f"{river_start[0]},{river_start[1]}"
                player_knows_river_start = river_start_key in player["known_tiles"]

                player["x"], player["y"] = river_start
                player["in_river"] = True

                if player_knows_river_start and not player["lost"]:
                    remember_visited_tile(player, river_start)
                    reveal_current_position(player, "arrived at")
                    remember_open_edge(player, pos, river_start)
                    set_player_message(player, "You used the raft. No injury, and you drifted to the known river start.")
                else:
                    enter_lost_state(player, "river")
                    start_lost_relative_map(player)
                    set_player_message(player, "You used the raft. No injury, but you were dragged to an unknown river start and became lost.")
            else:
                set_player_message(player, "You used the raft.")
            return "continue"

        player["injuries"] += 1
        if check_death(player, "Killed by river injury."):
            return "dead"

        enter_lost_state(player, "river")

        if river_start is not None:
            player["x"], player["y"] = river_start
            player["in_river"] = True
            start_lost_relative_map(player)

        if entered_own_birth_river and was_lost_before_entering_river:
            recover_from_lost(
                player,
                "The river dragged you to its start, but your birth tile let you get oriented again.",
            )
            return "continue"

        set_player_message(player, "The river injured you, dragged you to the river start, and you are now lost.")
        return "continue"

    set_player_message(player, f"You stepped on: {raw_tile}")
    return "continue"


def reveal_line(player, direction):
    dx, dy = DIRECTIONS[direction]
    x, y = player["x"], player["y"]
    revealed = []
    prev = (x, y)

    while True:
        if wall_blocks(x, y, direction):
            if not is_outer_wall(x, y, direction):
                nx, ny = x + dx, y + dy
                if in_bounds(nx, ny):
                    if player["lost"]:
                        remember_lost_edge(player, "lost_known_wall_edges", (x, y), (nx, ny))
                    else:
                        remember_wall_edge(player, (x, y), (nx, ny))
            break

        x += dx
        y += dy
        if not in_bounds(x, y):
            break

        current = (x, y)
        was_lost = player["lost"]
        if was_lost:
            remember_lost_edge(player, "lost_known_open_edges", prev, current)
            remember_visited_tile(player, current)
            remember_lost_tile(player, current, "used a flashlight on")
            recovered = check_previously_known_recovery(
                player,
                current,
                discovered_by_flashlight=True,
            )
        else:
            remember_open_edge(player, prev, current)
            reveal_position(player, current, "used a flashlight on")
            recovered = False
        revealed.append(current)
        if recovered or (was_lost and not player["lost"]):
            break
        prev = current

    return revealed


def validate_turn_action():
    if not GAME["game_started"]:
        return False, "Game has not started."
    if GAME["game_over"]:
        return False, "Game is over."
    if request.sid not in GAME["players"]:
        return False, "Player not found."

    player = GAME["players"][request.sid]
    if not player["alive"]:
        return False, "You are dead."
    if current_turn_sid() != request.sid:
        return False, "It is not your turn."
    prepare_player_turn(player)
    if GAME["pending_treasure"] is not None:
        return False, "Wait for the treasure reveal and confirm it before continuing."
    if GAME["pending_black_hole"] is not None:
        return False, "Waiting for manager to resolve a black hole."

    return True, ""


def serialize_player_public(player):
    return {
        "sid": player["sid"],
        "name": player["name"],
        "color": player.get("color", DEFAULT_PLAYER_COLOR),
        "x": player["x"],
        "y": player["y"],
        "birth_x": player["birth_x"],
        "birth_y": player["birth_y"],
        "alive": player["alive"],
        "spawned": player["spawned"],
        "injuries": player["injuries"],
        "bullets": player["bullets"],
        "bombs": player["bombs"],
        "items": copy.deepcopy(player["items"]),
        "known_open_edges": copy.deepcopy(player["known_open_edges"]),
        "known_broken_walls": copy.deepcopy(player["known_broken_walls"]),
        "known_wall_edges": copy.deepcopy(player["known_wall_edges"]),
        "last_message": player["last_message"],
        "lost": player["lost"],
        "lost_kind": player["lost_kind"],
        "connected": player.get("connected", True),
    }


def serialize_manager_state():
    return {
        "board_ready": GAME["board_ready"],
        "treasure_reveal": treasure_reveal_state(),
        "board": {f"{x},{y}": effective_tile_at((x, y)) for (x, y) in GAME["board"].keys()},
        "raw_board": {f"{x},{y}": GAME["board"][(x, y)] for (x, y) in GAME["board"].keys()},
        "inner_walls": [[list(a), list(b)] for (a, b) in GAME["inner_walls"]],
        "broken_walls": [serialize_edge(a, b) for a, b in GAME["broken_walls"]],
        "players": [serialize_player_public(p) for p in GAME["players"].values()],
        "player_order": GAME["player_order"],
        "current_turn_sid": current_turn_sid(),
        "game_started": GAME["game_started"],
        "game_over": GAME["game_over"],
        "winner_sid": GAME["winner_sid"],
        "winner_reason": GAME["winner_reason"],
        "turn_number": GAME["turn_number"],
        "logs": GAME["logs"][-80:],
        "pending_black_hole": GAME["pending_black_hole"],
        "pending_reconnect_claims": [
            {
                "sid": claim_sid,
                "name": claim["name"],
                "player_sid": claim["player_sid"],
            }
            for claim_sid, claim in GAME["pending_reconnect_claims"].items()
        ],
        "river_validation": river_validation(),
    }


def viewer_knows_exact_position(viewer, other):
    """Return true only when this viewer has been given the other position."""
    if other["sid"] in GAME["public_revealed_positions"]:
        return True
    if viewer["lost"]:
        return False
    return any(
        entry["sid"] == other["sid"]
        for entries in viewer["known_players"].values()
        for entry in entries
    )


def serialize_relative_trail(other, origin=None):
    """Create a coordinate-safe, lost-map-style board for another player."""
    if other["lost"]:
        return {
            "tiles": copy.deepcopy(other["lost_known_tiles"]),
            "open_edges": copy.deepcopy(other["lost_known_open_edges"]),
            "broken_walls": copy.deepcopy(other["lost_known_broken_walls"]),
            "wall_edges": copy.deepcopy(other["lost_known_wall_edges"]),
            "relative_position": {
                "x": other["lost_relative_x"],
                "y": other["lost_relative_y"],
            },
            "lost": True,
        }

    origin_x, origin_y = origin or (other["birth_x"], other["birth_y"])

    # Oriented players see the outside wall beside each discovered edge tile
    # on their main board. Preserve that same evidence in their public trail;
    # do not send a complete outer frame around unexplored squares.
    wall_edges = copy.deepcopy(other["known_wall_edges"])
    for key in other["known_tiles"]:
        x, y = map(int, key.split(','))
        for direction, (dx, dy) in DIRECTIONS.items():
            if is_outer_wall(x, y, direction):
                append_unique_edge(wall_edges, serialize_edge((x, y), (x + dx, y + dy)))

    def relative_tiles(tiles):
        translated = {}
        for key, tile in tiles.items():
            x, y = (int(value) for value in key.split(","))
            translated[f"{x - origin_x},{y - origin_y}"] = tile
        return translated

    def relative_edges(edges):
        translated = []
        for edge in edges:
            a, b = edge
            translated.append(serialize_edge(
                (a[0] - origin_x, a[1] - origin_y),
                (b[0] - origin_x, b[1] - origin_y),
            ))
        return translated

    return {
        "tiles": relative_tiles(other["known_tiles"]),
        "open_edges": relative_edges(other["known_open_edges"]),
        "broken_walls": relative_edges(other["known_broken_walls"]),
        "wall_edges": relative_edges(wall_edges),
        "relative_position": {
            "x": other["x"] - origin_x,
            "y": other["y"] - origin_y,
        },
        "lost": False,
    }


def serialize_hidden_player_maps_for(viewer):
    """Share relative trails only while a player's exact position is unknown."""
    trails = []
    river_start = find_river_start()
    viewer_has_river_anchor = (
        viewer.get("lost")
        and viewer.get("lost_kind") == "river"
        and player_knows_river_start(viewer)
    )
    for other in GAME["players"].values():
        if (
            other["sid"] == viewer["sid"]
            or not other["alive"]
            or other["x"] is None
            or other["y"] is None
            or viewer_knows_exact_position(viewer, other)
        ):
            continue
        river_relative = (
            viewer_has_river_anchor
            and not other.get("lost")
            and player_knows_river_start(other)
        )
        origin = river_start if river_relative else None
        if viewer["lost"] and not other["lost"] and other["sid"] in viewer["lost_birth_map_sources"]:
            origin = (viewer["x"] - viewer["lost_relative_x"], viewer["y"] - viewer["lost_relative_y"])
        trails.append({
            "sid": other["sid"],
            "name": other["name"],
            "color": other.get("color", DEFAULT_PLAYER_COLOR),
            **serialize_relative_trail(other, origin),
        })
    return trails


def serialize_known_birth_spots(viewer):
    """Label discovered birth tiles in the coordinates of the displayed map."""
    result = {}
    for owner in GAME["players"].values():
        pos = (owner["birth_x"], owner["birth_y"])
        if None in pos:
            continue
        if viewer["lost"]:
            relative = lost_relative_position_for(viewer, pos)
            key = f"{relative[0]},{relative[1]}"
            visible = key in viewer["lost_known_tiles"]
        else:
            key = f"{pos[0]},{pos[1]}"
            visible = key in viewer["known_tiles"] or owner["sid"] == viewer["sid"]
        if visible:
            result.setdefault(key, []).append({"name": owner["name"]})
    return result


def serialize_public_player_stats():
    fields = ("sid", "name", "color", "alive", "spawned", "injuries", "bullets", "bombs", "items", "lost", "connected")
    return [{field: copy.deepcopy(player[field]) for field in fields} for player in GAME["players"].values()]


def serialize_saved_maps(player):
    """Retained discoveries, without a lost player's current position or notes."""
    saved = copy.deepcopy(player["map_archive"])
    if player["lost"] and player["known_tiles"]:
        snapshot = dict(player, lost=False)
        trail = serialize_relative_trail(snapshot)
        trail.pop("relative_position", None)
        positions = []
        for other in GAME["players"].values():
            if other is player or not other["alive"] or other["lost"] or not other["spawned"]:
                continue
            same_group = player["fusion_group"] is not None and player["fusion_group"] == other["fusion_group"]
            matching_anchor = any(key in other["known_tiles"] and tile_allows_map_fusion(tuple(map(int, key.split(','))))
                                  for key in player["known_tiles_before_lost"])
            if same_group or matching_anchor or other["sid"] in GAME["public_revealed_positions"]:
                positions.append({"sid": other["sid"], "name": other["name"], "color": other["color"],
                                  "x": other["x"] - player["birth_x"], "y": other["y"] - player["birth_y"]})
        trail.update(id=f"saved-{player['sid']}", name=f"{player['name']} — saved map",
                     players=positions, member_sids=[player["sid"]] + [p["sid"] for p in positions], archived=True, absolute=False)
        saved.insert(0, trail)
    return saved


def serialize_manager_map():
    births = {}
    for player in GAME["players"].values():
        if player["spawned"]:
            births.setdefault(f"{player['birth_x']},{player['birth_y']}", []).append({"name": player["name"]})
    walls = [serialize_edge(a, b) for a, b in GAME["inner_walls"]]
    for n in range(BOARD_SIZE):
        walls.extend([serialize_edge((n, 0), (n, -1)), serialize_edge((n, 9), (n, 10)),
                      serialize_edge((0, n), (-1, n)), serialize_edge((9, n), (10, n))])
    return {
        "name": "Manager map", "absolute": True, "manager_map": True,
        "id": "manager", "member_sids": list(GAME["players"]),
        "tiles": {f"{x},{y}": effective_tile_at((x, y)) for x, y in GAME["board"]},
        "wall_edges": walls, "open_edges": [],
        "broken_walls": [serialize_edge(a, b) for a, b in GAME["broken_walls"]],
        "birth_spots": births,
        "players": [{"sid": p["sid"], "name": p["name"], "color": p["color"], "x": p["x"], "y": p["y"]}
                    for p in GAME["players"].values() if p["spawned"]],
    }


def serialize_public_boards_state():
    """Discovered maps during play; reveal the manager board only at game over."""
    boards = []
    seen_groups = set()
    for player in GAME["players"].values():
        if not player["spawned"] or None in (player["x"], player["y"]):
            continue
        boards.extend(serialize_saved_maps(player))
        if player["lost"] and player["lost_kind"] == "river":
            continue
        group = player.get("fusion_group") if not player["lost"] else None
        lost_members = []
        if player["lost"] and player["lost_fusion_links"]:
            lost_members = [p for p in GAME["players"].values() if p["alive"] and p["lost"]
                            and p["sid"] in [player["sid"], *player["lost_fusion_links"]]]
            group = "lost-" + ",".join(sorted(p["sid"] for p in lost_members))
        if group is not None:
            if group in seen_groups:
                continue
            seen_groups.add(group)
        members = lost_members or (fusion_group_members(group) if group is not None else [player])
        absolute = not player["lost"] and any(p["sid"] in GAME["public_revealed_positions"] for p in members)
        origin = (0, 0) if absolute else (player["birth_x"], player["birth_y"])
        trail = serialize_relative_trail(player, origin)
        positions = []
        for member in members:
            if player["lost"]:
                rx, ry = lost_relative_position_for(player, (member["x"], member["y"]))
                member_trail = {**trail, "relative_position": {"x": rx, "y": ry}}
            else:
                member_trail = serialize_relative_trail(member, origin)
            trail["tiles"].update(member_trail["tiles"])
            for field in ("open_edges", "broken_walls", "wall_edges"):
                for edge in member_trail[field]:
                    append_unique_edge(trail[field], edge)
            if member["alive"]:
                positions.append({"sid": member["sid"], "name": member["name"], "color": member["color"], **member_trail["relative_position"]})
        birth_spots = {}
        for owner in GAME["players"].values():
            birth = (owner["birth_x"], owner["birth_y"])
            if None in birth:
                continue
            relative = lost_relative_position_for(player, birth) if player["lost"] else (birth[0] - origin[0], birth[1] - origin[1])
            key = f"{relative[0]},{relative[1]}"
            if key in trail["tiles"]:
                birth_spots.setdefault(key, []).append({"name": owner["name"]})
        boards.append({"id": f"group-{group}" if group is not None else f"player-{player['sid']}",
                       "member_sids": [p["sid"] for p in members], "name": ", ".join(p["name"] for p in members), "absolute": absolute, **trail, "players": positions, "birth_spots": birth_spots})
    river_map = GAME["river_lost_map"]
    if river_map["tiles"]:
        positions = [{"sid": p["sid"], "name": p["name"], "color": p["color"], "x": p["lost_relative_x"], "y": p["lost_relative_y"]}
                     for p in GAME["players"].values() if p["alive"] and p["lost"] and p["lost_kind"] == "river"]
        boards.append({"id": "river", "member_sids": [p["sid"] for p in positions], "name": "Shared river map", "absolute": False, "lost": True, **copy.deepcopy(river_map), "players": positions})
    if GAME["game_over"]:
        boards.insert(0, serialize_manager_map())
    return mask_treasure_suspense({"boards": boards, "players": serialize_public_player_stats(), "logs": list(GAME["logs"]), "treasure_reveal": treasure_reveal_state(), "game_started": GAME["game_started"], "game_over": GAME["game_over"], "turn_number": GAME["turn_number"]})


def serialize_player_state_for(sid):
    player = GAME["players"].get(sid)
    if not player:
        return {}

    sync_river_lost_map_to_player(player)
    refresh_lost_river_player_positions()

    turn_sid = current_turn_sid()

    # A river or black hole hides the player's current position, not the map
    # they already made.  Each player always keeps their own discoveries.
    if player["lost"]:
        known_tiles = copy.deepcopy(player["lost_known_tiles"])
        manual_tiles = copy.deepcopy(player["lost_manual_tiles"])
        manual_wall_edges = copy.deepcopy(player["lost_manual_wall_edges"])
        known_players = copy.deepcopy(player["lost_known_players"])
        for peer_sid in player["lost_fusion_links"]:
            peer = GAME["players"].get(peer_sid)
            if peer and peer["alive"] and peer["lost"]:
                rx, ry = lost_relative_position_for(player, (peer["x"], peer["y"]))
                known_players.setdefault(f"{rx},{ry}", []).append({"sid": peer_sid, "name": peer["name"], "color": peer["color"]})
        for key, players in player["lost_river_players"].items():
            known_players.setdefault(key, [])
            for other in players:
                if not any(existing["sid"] == other["sid"] for existing in known_players[key]):
                    known_players[key].append(copy.deepcopy(other))
        # Physical meetings are visible even when the map is still relative.
        own_key = f"{player['lost_relative_x']},{player['lost_relative_y']}"
        for other in GAME["players"].values():
            if other["sid"] != sid and other["alive"] and (other["x"], other["y"]) == (player["x"], player["y"]):
                entries = known_players.setdefault(own_key, [])
                if not any(entry["sid"] == other["sid"] for entry in entries):
                    entries.append({"sid": other["sid"], "name": other["name"], "color": other["color"]})
        known_open_edges = copy.deepcopy(player["lost_known_open_edges"])
        known_broken_walls = copy.deepcopy(player["lost_known_broken_walls"])
        known_wall_edges = copy.deepcopy(player["lost_known_wall_edges"])
    else:
        known_tiles = copy.deepcopy(player["known_tiles"])
        manual_tiles = copy.deepcopy(player["manual_tiles"])
        manual_wall_edges = copy.deepcopy(player["manual_wall_edges"])
        known_players = copy.deepcopy(player["known_players"])
        known_open_edges = copy.deepcopy(player["known_open_edges"])
        known_broken_walls = copy.deepcopy(player["known_broken_walls"])
        known_wall_edges = copy.deepcopy(player["known_wall_edges"])
        if player["fusion_group"] is not None:
            # Derive live fused positions on every snapshot, including rejoin.
            for member in fusion_group_members(player["fusion_group"]):
                if member["sid"] == sid or None in (member["x"], member["y"]):
                    continue
                for entries in known_players.values():
                    entries[:] = [p for p in entries if p["sid"] != member["sid"]]
                key = f"{member['x']},{member['y']}"
                known_players.setdefault(key, []).append({field: member[field] for field in ("sid", "name", "color", "x", "y")})
    player_view = serialize_player_public(player)

    # The manager remains the only client who receives a lost player's actual
    # location.  The game server still uses it to validate every action.
    if player["lost"]:
        player_view["x"] = None
        player_view["y"] = None

    return mask_treasure_suspense({
        "board_ready": GAME["board_ready"],
        "treasure_reveal": treasure_reveal_state(),
        "you": player_view,
        "players": serialize_public_player_stats(),
        "public_revealed_players": list(GAME["public_revealed_positions"].values()),
        "lost_relative_position": {
            "x": player["lost_relative_x"],
            "y": player["lost_relative_y"],
        } if player["lost"] else None,
        "your_known_tiles": known_tiles,
        "birth_spots": serialize_known_birth_spots(player),
        "your_manual_tiles": manual_tiles,
        "your_manual_wall_edges": manual_wall_edges,
        "your_known_players": known_players,
        "your_known_open_edges": known_open_edges,
        "your_known_broken_walls": known_broken_walls,
        "your_known_wall_edges": known_wall_edges,
        "hidden_player_maps": serialize_hidden_player_maps_for(player),
        "saved_maps": serialize_saved_maps(player),
        "spectator_map": serialize_manager_map() if not player["alive"] else None,
        "map_progress": map_completion_progress(player),
        "lost_map_bounds": lost_map_bounds(player) if player["lost"] else None,
        "river_map": {
            "players": [{"sid": p["sid"], "name": p["name"], "color": p["color"], "x": p["lost_relative_x"], "y": p["lost_relative_y"]}
                        for p in GAME["players"].values() if p["alive"] and p["lost"] and p["lost_kind"] == "river"],
            "tiles": copy.deepcopy(GAME["river_lost_map"]["tiles"]),
            "open_edges": copy.deepcopy(GAME["river_lost_map"]["open_edges"]),
            "broken_walls": copy.deepcopy(GAME["river_lost_map"]["broken_walls"]),
            "wall_edges": copy.deepcopy(GAME["river_lost_map"]["wall_edges"]),
        },
        "board_size": BOARD_SIZE,
        "current_turn_sid": turn_sid,
        "current_turn_name": GAME["players"][turn_sid]["name"] if turn_sid in GAME["players"] else None,
        "is_your_turn": turn_sid == sid,
        "game_started": GAME["game_started"],
        "game_over": GAME["game_over"],
        "winner_sid": GAME["winner_sid"],
        "winner_reason": GAME["winner_reason"],
        "turn_number": GAME["turn_number"],
        "logs": GAME["logs"][-30:],
        "pending_black_hole": GAME["pending_black_hole"],
    })


def sync_lost_fusion_maps():
    # Snapshot first: recovery is checked separately, without a cascade of
    # fresh normal-map information from a player who just became oriented.
    sources = {p["sid"]: copy.deepcopy(p) for p in GAME["players"].values()
               if p["alive"] and p["lost"] and p["lost_fusion_links"]}
    for sid, source in sources.items():
        receiver = GAME["players"][sid]
        new_positions = []
        for peer_sid in source["lost_fusion_links"]:
            donor = sources.get(peer_sid)
            if not donor:
                continue
            origin = (donor["x"] - donor["lost_relative_x"], donor["y"] - donor["lost_relative_y"])
            def actual(point):
                return (point[0] + origin[0], point[1] + origin[1])
            for key, tile in donor["lost_known_tiles"].items():
                pos = actual(tuple(map(int, key.split(','))))
                rx, ry = lost_relative_position_for(receiver, pos)
                relative_key = f"{rx},{ry}"
                if relative_key not in receiver["lost_known_tiles"]:
                    new_positions.append(pos)
                receiver["lost_known_tiles"][relative_key] = tile
                receiver["lost_manual_tiles"].pop(relative_key, None)
            for field in ("lost_known_open_edges", "lost_known_wall_edges", "lost_known_broken_walls"):
                for edge in donor[field]:
                    append_unique_edge(receiver[field], serialize_edge(lost_relative_position_for(receiver, actual(edge[0])),
                                                                       lost_relative_position_for(receiver, actual(edge[1]))))
            for key, clues in donor["lost_outer_wall_bomb_clues"].items():
                rx, ry = lost_relative_position_for(receiver, actual(tuple(map(int, key.split(',')))))
                existing = receiver["lost_outer_wall_bomb_clues"].setdefault(f"{rx},{ry}", [])
                existing.extend(clue for clue in clues if clue not in existing)
        if receiver["lost_kind"] == "river":
            GAME["river_lost_map"]["tiles"].update(receiver["lost_known_tiles"])
            for field, target in (("lost_known_open_edges", "open_edges"), ("lost_known_wall_edges", "wall_edges"), ("lost_known_broken_walls", "broken_walls")):
                for edge in receiver[field]:
                    append_unique_edge(GAME["river_lost_map"][target], edge)
        for pos in new_positions:
            if check_previously_known_recovery(receiver, pos):
                break
            discover_lost_birth_tile(receiver, pos)
            if not receiver["lost"]:
                break
        if receiver["lost"]:
            check_lost_map_completion(receiver)


def emit_full_state():
    sync_lost_fusion_maps()
    resolve_shared_river_discoveries()
    for player in list(GAME["players"].values()):
        if player["lost"] and player["lost_birth_map_sources"]:
            sync_lost_birth_maps(player)
            check_lost_map_completion(player)
    sync_all_map_fusion_groups()
    refresh_known_player_positions()
    GAME["public_revealed_positions"] = {
        sid: {
            "sid": player["sid"],
            "name": player["name"],
            "color": player.get("color", DEFAULT_PLAYER_COLOR),
            "x": player["x"],
            "y": player["y"],
        }
        for sid in GAME["public_revealed_positions"]
        if (player := GAME["players"].get(sid))
        and player["alive"]
        and not player["lost"]
        and player["x"] is not None
        and player["y"] is not None
    }
    refresh_lost_river_player_positions()
    socketio.emit("manager_state", serialize_manager_state(), room="manager_room")
    for sid in list(GAME["players"].keys()):
        socketio.emit("player_state", serialize_player_state_for(sid), room=sid)
    socketio.emit("public_boards_state", serialize_public_boards_state(), room="public_boards_room")


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/manager")
def manager():
    return render_template("manager.html")


@app.route("/boards")
def public_boards():
    return render_template("boards.html")


@app.route("/api/public-boards")
def public_boards_snapshot():
    return serialize_public_boards_state(), 200, {"Cache-Control": "no-store"}


@socketio.on("watch_public_boards")
def watch_public_boards():
    socketio.server.enter_room(request.sid, "public_boards_room")
    emit("public_boards_state", serialize_public_boards_state())


@socketio.on("connect")
def on_connect():
    emit("connected", {"sid": request.sid})


@socketio.on("disconnect")
def on_disconnect(reason=None):
    global MANAGER_SID
    sid = request.sid

    GAME["pending_reconnect_claims"].pop(sid, None)

    if sid == MANAGER_SID:
        MANAGER_SID = None

    if sid in GAME["players"]:
        player = GAME["players"][sid]
        player["connected"] = False
        log(f"{player['name']} temporarily disconnected. Their game will be restored when they reconnect.")

    emit_full_state()


def restore_player_connection(old_sid, new_sid, *, color=None):
    """Move one retained player session onto a newly connected socket."""
    active_sid = current_turn_sid()
    player = GAME["players"].pop(old_sid)
    player["sid"] = new_sid
    player["connected"] = True
    if color is not None:
        player["color"] = normalize_player_color(color)
    GAME["players"][new_sid] = player
    GAME["player_order"] = [new_sid if player_sid == old_sid else player_sid for player_sid in GAME["player_order"]]
    for candidate in GAME["players"].values():
        candidate["lost_fusion_links"] = [new_sid if sid == old_sid else sid for sid in candidate["lost_fusion_links"]]
        candidate["lost_birth_map_sources"] = [
            new_sid if source_sid == old_sid else source_sid
            for source_sid in candidate["lost_birth_map_sources"]
        ]
        candidate["fusion_history"] = [
            new_sid if historical_sid == old_sid else historical_sid
            for historical_sid in candidate.get("fusion_history", [])
        ]
    if GAME["pending_black_hole"] and GAME["pending_black_hole"]["player_sid"] == old_sid:
        GAME["pending_black_hole"]["player_sid"] = new_sid
    if GAME["pending_treasure"] and GAME["pending_treasure"]["player_sid"] == old_sid:
        GAME["pending_treasure"]["player_sid"] = new_sid
    for pending in GAME["treasure_queue"]:
        if pending["player_sid"] == old_sid:
            pending["player_sid"] = new_sid
    for archived in player["map_archive"]:
        archived["member_sids"] = [new_sid]
    if GAME["winner_sid"] == old_sid:
        GAME["winner_sid"] = new_sid
    if active_sid == old_sid:
        active_sid = new_sid
    if active_sid and active_sid in GAME["players"]:
        GAME["current_turn_index"] = alive_player_sids_in_order().index(active_sid)
    else:
        GAME["current_turn_index"] = 0
    for claim_sid, claim in list(GAME["pending_reconnect_claims"].items()):
        if claim["player_sid"] == old_sid:
            del GAME["pending_reconnect_claims"][claim_sid]
    socketio.server.enter_room(new_sid, new_sid)
    return player


@socketio.on("join_player")
def join_player(data):
    sid = request.sid
    name = (data.get("name") or "").strip()
    color = normalize_player_color(data.get("color"))

    if not name:
        emit("error_message", {"message": "Name is required."})
        return

    matching_player = next(
        (
            (player_sid, player) for player_sid, player in GAME["players"].items()
            if player_sid != sid and player["name"].casefold() == name.casefold()
        ),
        None,
    )
    if matching_player:
        old_sid, old_player = matching_player
        if old_player.get("connected", True):
            emit("error_message", {"message": "That player name is already in use."})
            return
        GAME["pending_reconnect_claims"][sid] = {
            "player_sid": old_sid,
            "name": old_player["name"],
            "color": color,
        }
        emit("reconnect_claim_pending", {
            "name": old_player["name"],
            "message": "Waiting for the manager to approve this reconnect request.",
        })
        log(f"A new tab requested manager approval to reconnect as {old_player['name']}.")
        socketio.emit("reconnect_claim_requested", {
            "sid": sid,
            "name": old_player["name"],
        }, to="manager_room")
        emit_full_state()
        return

    if GAME["game_started"] and sid not in GAME["players"]:
        emit("error_message", {"message": "A game is already in progress. Join the next game after a reset."})
        return

    if sid not in GAME["players"]:
        GAME["players"][sid] = create_player(sid, name, color)
        log(f"{name} joined the game.")
    else:
        GAME["players"][sid]["name"] = name
        GAME["players"][sid]["color"] = color
        GAME["players"][sid]["connected"] = True

    socketio.server.enter_room(sid, sid)
    emit("joined_as_player", {
        "sid": sid,
        "name": name,
    })
    emit_full_state()


@socketio.on("resume_player")
def resume_player(data):
    # Player identity is deliberately restored only through a manager-approved
    # claim. Browser storage is shared by tabs, so a token must never decide
    # which player a newly opened tab becomes.
    emit("resume_failed", {
        "message": "Player reconnects require manager approval. Enter your name and ask the manager."
    })


@socketio.on("manager_approve_reconnect")
def manager_approve_reconnect(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can approve reconnect requests."})
        return
    claim_sid = (data or {}).get("sid")
    claim = GAME["pending_reconnect_claims"].get(claim_sid)
    if not claim or claim["player_sid"] not in GAME["players"]:
        emit("error_message", {"message": "That reconnect request is no longer available."})
        return
    old_player = GAME["players"][claim["player_sid"]]
    if old_player.get("connected", True):
        emit("error_message", {"message": "That player is already connected."})
        return

    player = restore_player_connection(claim["player_sid"], claim_sid, color=claim["color"])
    set_player_message(player, "The manager approved your reconnect. Your game was restored.")
    log(f"Manager approved the reconnect for {player['name']}.")
    socketio.emit("resumed_as_player", {
        "sid": claim_sid,
        "name": player["name"],
    }, to=claim_sid)
    emit_full_state()


@socketio.on("manager_reject_reconnect")
def manager_reject_reconnect(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can reject reconnect requests."})
        return
    claim_sid = (data or {}).get("sid")
    claim = GAME["pending_reconnect_claims"].pop(claim_sid, None)
    if not claim:
        emit("error_message", {"message": "That reconnect request is no longer available."})
        return
    socketio.emit("reconnect_claim_rejected", {
        "message": "The manager did not approve this reconnect request."
    }, to=claim_sid)
    emit_full_state()


@socketio.on("manager_confirm_player_left")
def manager_confirm_player_left(data):
    """A confirmed departure during play is a death, not a deleted player."""
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can confirm a player has left."})
        return

    player_sid = (data or {}).get("sid")
    player = GAME["players"].get(player_sid)
    if not player:
        emit("error_message", {"message": "That player is no longer in this game."})
        return
    if player.get("connected", True):
        emit("error_message", {"message": "A connected player cannot be removed as disconnected."})
        return
    if GAME["game_started"] and not player["alive"]:
        emit("error_message", {"message": "That player is already dead."})
        return

    old_order = alive_player_sids_in_order()
    was_current = current_turn_sid() == player_sid
    removed_index = old_order.index(player_sid) if player_sid in old_order else None
    if GAME["game_started"]:
        player["alive"] = False
        player["spawn_effect_pending"] = False
        player["extra_turn"] = False
        drop_held_items(player)
        set_player_message(player, "The manager confirmed your departure. You now count as dead.")
    else:
        del GAME["players"][player_sid]
        GAME["player_order"] = [sid for sid in GAME["player_order"] if sid != player_sid]
    GAME["public_revealed_positions"].pop(player_sid, None)

    for claim_sid, claim in list(GAME["pending_reconnect_claims"].items()):
        if claim["player_sid"] == player_sid:
            del GAME["pending_reconnect_claims"][claim_sid]
            socketio.emit("reconnect_claim_rejected", {
                "message": "The manager confirmed that this player left the game."
            }, to=claim_sid)

    if GAME["pending_black_hole"] and GAME["pending_black_hole"]["player_sid"] == player_sid:
        GAME["pending_black_hole"] = None
    if GAME["pending_treasure"] and GAME["pending_treasure"]["player_sid"] == player_sid:
        GAME["pending_treasure"] = None
    GAME["treasure_queue"] = [pending for pending in GAME["treasure_queue"] if pending["player_sid"] != player_sid]
    advance_treasure_queue()

    new_order = alive_player_sids_in_order()
    if new_order:
        if was_current:
            GAME["current_turn_index"] %= len(new_order)
        elif removed_index is not None and removed_index < GAME["current_turn_index"]:
            GAME["current_turn_index"] -= 1
    else:
        GAME["current_turn_index"] = 0

    log(f"Manager confirmed that {player['name']} left the game.")
    if GAME["game_started"]:
        check_last_player_win()
        if not GAME["game_over"] and not GAME["pending_treasure"] and (was_current or GAME["start_turn_after_treasure"]):
            GAME["start_turn_after_treasure"] = False
            start_current_turn()
    emit_full_state()


@socketio.on("join_manager")
def join_manager(data=None):
    global MANAGER_SID, MANAGER_RECONNECT_TOKEN
    MANAGER_SID = request.sid
    if not MANAGER_RECONNECT_TOKEN:
        MANAGER_RECONNECT_TOKEN = secrets.token_urlsafe(32)
    socketio.server.enter_room(request.sid, "manager_room")
    emit("joined_as_manager", {"sid": request.sid, "reconnect_token": MANAGER_RECONNECT_TOKEN})
    emit_full_state()


@socketio.on("resume_manager")
def resume_manager(data):
    global MANAGER_SID
    token = (data or {}).get("reconnect_token")
    if not MANAGER_RECONNECT_TOKEN or not secrets.compare_digest(
        MANAGER_RECONNECT_TOKEN, str(token or "")
    ):
        emit("resume_failed", {"message": "Your manager session is no longer available. Join as manager again."})
        return
    MANAGER_SID = request.sid
    socketio.server.enter_room(request.sid, "manager_room")
    emit("resumed_as_manager", {"sid": request.sid})
    emit_full_state()


@socketio.on("manager_set_tile")
def manager_set_tile(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can edit the board."})
        return

    if GAME["game_started"]:
        emit("error_message", {"message": "The board is locked while a game is in progress. Reset the game to edit it."})
        return

    if GAME["board_ready"]:
        emit("error_message", {"message": "The board is ready and locked. Reset the game to edit it."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
        tile = data["tile"]
    except Exception:
        emit("error_message", {"message": "Invalid tile data."})
        return

    if not in_bounds(x, y):
        emit("error_message", {"message": "Tile out of bounds."})
        return

    if tile not in TILE_TYPES:
        emit("error_message", {"message": "Invalid tile type."})
        return

    if tile == "exit" and not is_edge_tile(x, y):
        emit("error_message", {"message": "Exit must be placed on an outer edge tile."})
        return

    current_tile = GAME["board"][(x, y)]
    if tile in REQUIRED_SINGLE_TILES:
        duplicate_exists = any(
            pos != (x, y) and board_tile == tile
            for pos, board_tile in GAME["board"].items()
        )
        if duplicate_exists:
            emit("error_message", {"message": f"Only one {tile} tile is allowed."})
            return

    if tile == "river_start":
        duplicate_start_exists = any(
            pos != (x, y) and board_tile == "river_start"
            for pos, board_tile in GAME["board"].items()
        )
        if duplicate_start_exists:
            emit("error_message", {"message": "Only one river_start tile is allowed."})
            return

    if tile in {"river", "river_start"} and current_tile not in {"river", "river_start"}:
        if len(get_river_positions()) >= 20:
            emit("error_message", {"message": "River may use at most 20 tiles including river_start."})
            return

    GAME["board"][(x, y)] = tile
    GAME["consumed_tiles"].discard((x, y))
    emit_full_state()


@socketio.on("manager_toggle_inner_wall")
def manager_toggle_inner_wall(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can edit walls."})
        return

    if GAME["game_started"]:
        emit("error_message", {"message": "The board is locked while a game is in progress. Reset the game to edit it."})
        return

    if GAME["board_ready"]:
        emit("error_message", {"message": "The board is ready and locked. Reset the game to edit it."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
        direction = data["direction"]
    except Exception:
        emit("error_message", {"message": "Invalid wall data."})
        return

    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid direction."})
        return

    if not in_bounds(x, y):
        emit("error_message", {"message": "Coordinates out of bounds."})
        return

    if is_outer_wall(x, y, direction):
        emit("error_message", {"message": "Outer walls cannot be edited."})
        return

    dx, dy = DIRECTIONS[direction]
    nx, ny = x + dx, y + dy
    if not in_bounds(nx, ny):
        emit("error_message", {"message": "Invalid inner wall edge."})
        return

    ek = edge_key((x, y), (nx, ny))
    if ek in GAME["inner_walls"]:
        GAME["inner_walls"].remove(ek)
    else:
        GAME["inner_walls"].add(ek)

    emit_full_state()


def validate_imported_map(layout):
    """Validate an entire candidate without changing the running board."""
    if not isinstance(layout, dict) or layout.get("size") != BOARD_SIZE:
        raise ValueError("Invalid map file.")
    tiles = layout.get("tiles")
    expected = {f"{x},{y}" for x in range(BOARD_SIZE) for y in range(BOARD_SIZE)}
    if not isinstance(tiles, dict) or set(tiles) != expected:
        raise ValueError("Invalid map file.")
    if any(not isinstance(tile, str) or tile not in TILE_TYPES for tile in tiles.values()):
        raise ValueError("Invalid map file.")
    board = {tuple(map(int, key.split(","))): tile for key, tile in tiles.items()}
    raw_walls = layout.get("inner_walls", [])
    if not isinstance(raw_walls, list) or len(raw_walls) > 180:
        raise ValueError("Invalid map file.")
    walls = set()
    for edge in raw_walls:
        if not isinstance(edge, list) or len(edge) != 2:
            raise ValueError("Invalid map file.")
        if any(not isinstance(p, list) or len(p) != 2 or
               any(type(n) is not int or not 0 <= n < BOARD_SIZE for n in p) for p in edge):
            raise ValueError("Invalid map file.")
        a, b = map(tuple, edge)
        if abs(a[0]-b[0]) + abs(a[1]-b[1]) != 1:
            raise ValueError("Invalid map file.")
        walls.add(edge_key(a, b))
    for validation in (required_tile_validation(board), river_validation(board, walls)):
        if not validation["ok"]:
            raise ValueError(validation["message"])
    if any(tile == "exit" and not is_edge_tile(*pos) for pos, tile in board.items()):
        raise ValueError("Exit must be placed on an outer edge tile.")
    seen, pending = set(), [(0, 0)]
    while pending:
        pos = pending.pop()
        if pos in seen:
            continue
        seen.add(pos)
        for dx, dy in DIRECTIONS.values():
            nxt = pos[0]+dx, pos[1]+dy
            if nxt in board and nxt not in seen and edge_key(pos, nxt) not in walls:
                pending.append(nxt)
    if len(seen) != BOARD_SIZE * BOARD_SIZE:
        raise ValueError("The map has unreachable tiles.")
    return board, walls


@socketio.on("manager_load_map")
def manager_load_map(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can load a map."})
        return
    if GAME["game_started"] or GAME["board_ready"] or any(p["spawned"] for p in GAME["players"].values()):
        emit("error_message", {"message": "Reset the game before loading a map."})
        return
    if not isinstance(data, dict) or data.get("confirmed") is not True:
        emit("error_message", {"message": "Confirm replacing the board before loading a map."})
        return
    try:
        if "preset_id" in data:
            preset = data["preset_id"]
            if preset not in ("map-1", "map-2", "map-3"):
                raise ValueError("Invalid map file.")
            layout = json.loads((Path(__file__).parent / "maps" / (preset + ".json")).read_text(encoding="utf-8"))
        else:
            layout = data.get("layout")
            if len(json.dumps(layout)) > 100_000:
                raise ValueError("Invalid map file.")
        board, walls = validate_imported_map(layout)
    except (ValueError, TypeError, OSError) as error:
        message = str(error) if isinstance(error, ValueError) and not isinstance(error, json.JSONDecodeError) else "Invalid map file."
        emit("error_message", {"message": message})
        return
    GAME["board"] = board
    GAME["inner_walls"] = walls
    GAME["consumed_tiles"].clear()
    GAME["broken_walls"].clear()
    GAME["dropped_items"].clear()
    log("The manager loaded a map. Spawning stays closed until Board ready.")
    emit("map_loaded", {"message": "Map loaded. Review it, then click Board ready. Players can spawn anywhere."})
    emit_full_state()


@socketio.on("manager_clear_board")
def manager_clear_board():
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can clear the board."})
        return

    if GAME["game_started"]:
        emit("error_message", {"message": "The board is locked while a game is in progress. Reset the game to edit it."})
        return

    if GAME["board_ready"]:
        emit("error_message", {"message": "The board is ready and locked. Reset the game to edit it."})
        return

    for pos in GAME["board"]:
        GAME["board"][pos] = "empty"
    GAME["consumed_tiles"].clear()
    GAME["inner_walls"].clear()
    GAME["broken_walls"].clear()
    emit_full_state()


@socketio.on("manager_reset_game")
def manager_reset_game():
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can reset the game."})
        return
    reset_game()


@socketio.on("manager_board_ready")
def manager_board_ready():
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can mark the board ready."})
        return
    if GAME["game_started"] or GAME["board_ready"]:
        return
    for validation in (river_validation(), required_tile_validation()):
        if not validation["ok"]:
            emit("error_message", {"message": f"Cannot open spawning: {validation['message']}"})
            return
    if any(tile == "exit" and not is_edge_tile(*pos) for pos, tile in GAME["board"].items()):
        emit("error_message", {"message": "Exit must be placed on an outer edge tile."})
        return
    GAME["board_ready"] = True
    log("The manager marked the board ready. Players may now choose a spawn tile.")
    emit_full_state()


@socketio.on("acknowledge_treasure")
def acknowledge_treasure():
    pending = GAME["pending_treasure"]
    if not pending or pending["player_sid"] != request.sid or pending["phase"] != "revealed":
        emit("error_message", {"message": "Wait for the treasure reveal before confirming."})
        return
    GAME["pending_treasure"] = None
    advance_treasure_queue()
    if GAME["pending_treasure"]:
        emit_full_state()
    elif GAME["start_turn_after_treasure"]:
        GAME["start_turn_after_treasure"] = False
        start_current_turn()
        emit_full_state()
    elif pending["end_turn_requested"]:
        end_turn()
    else:
        emit_full_state()


@socketio.on("manager_start_game")
def manager_start_game():
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can start the game."})
        return

    if GAME["game_started"]:
        emit("error_message", {"message": "Game already started."})
        return

    if not GAME["board_ready"]:
        emit("error_message", {"message": "Finish the board and click Board ready before players can spawn."})
        return

    if not all_spawned():
        emit("error_message", {"message": "Need at least 2 spawned players."})
        return

    validation = river_validation()
    if not validation["ok"]:
        emit("error_message", {"message": f"Cannot start: {validation['message']}"})
        return

    required_tiles = required_tile_validation()
    if not required_tiles["ok"]:
        emit("error_message", {"message": f"Cannot start: {required_tiles['message']}"})
        return

    GAME["player_order"] = list(GAME["players"].keys())
    random.shuffle(GAME["player_order"])
    GAME["current_turn_index"] = 0
    GAME["game_started"] = True
    GAME["game_over"] = False
    GAME["winner_sid"] = None
    GAME["winner_reason"] = ""
    GAME["turn_number"] = 1
    GAME["pending_black_hole"] = None

    for player in GAME["players"].values():
        player["lost"] = False
        player["lost_kind"] = None
        player["map_fusion_blocked_until_turn"] = 0
        player["in_river"] = False
        player["lost_exit_visible_position"] = None
        player["known_tiles_before_lost"] = {}
        player["known_open_edges_before_lost"] = []
        player["known_broken_walls_before_lost"] = []
        player["known_wall_edges_before_lost"] = []
        player["last_lost_known_tiles"] = {}
        player["lost_known_tiles"] = {}
        player["lost_known_players"] = {}
        player["lost_known_open_edges"] = []
        player["lost_known_broken_walls"] = []
        player["lost_known_wall_edges"] = []
        player["spawn_effect_pending"] = True
        set_player_message(player, "Your starting-tile effect will apply when your first turn starts.")

    # Starting occupants claim pickup tiles before anybody can take a turn.
    # Co-spawned players resolve the single item in the randomized turn order.
    for sid in GAME["player_order"]:
        player = GAME["players"][sid]
        pos = (player["x"], player["y"])
        if GAME["board"][pos] in PICKUP_TILES:
            player["spawn_effect_pending"] = False
            apply_tile_effect(player, "started the game on", grant_extra_turn=False)
    refresh_known_player_positions()

    log("Game started.")
    if GAME["pending_treasure"]:
        GAME["start_turn_after_treasure"] = True
    else:
        start_current_turn()
    turn_sid = current_turn_sid()
    if turn_sid in GAME["players"]:
        log(f"First turn: {GAME['players'][turn_sid]['name']}")

    emit_full_state()


@socketio.on("player_spawn")
def player_spawn(data):
    sid = request.sid
    if sid not in GAME["players"]:
        emit("error_message", {"message": "Join first."})
        return

    if GAME["game_started"]:
        emit("error_message", {"message": "Game already started."})
        return

    if not GAME["board_ready"]:
        emit("error_message", {"message": "Wait for the manager to mark the board ready."})
        return
    if GAME["players"][sid]["spawned"]:
        emit("error_message", {"message": "Your spawn is already locked in."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
    except Exception:
        emit("error_message", {"message": "Invalid spawn coordinates."})
        return

    if not in_bounds(x, y):
        emit("error_message", {"message": "Spawn out of bounds."})
        return

    player = GAME["players"][sid]
    player["x"] = x
    player["y"] = y
    player["birth_x"] = x
    player["birth_y"] = y
    player["spawned"] = True
    player["lost"] = False
    player["known_tiles"] = {}
    player["manual_tiles"] = {}
    player["manual_wall_edges"] = []
    player["known_tiles_before_lost"] = {}
    player["known_open_edges_before_lost"] = []
    player["known_broken_walls_before_lost"] = []
    player["known_wall_edges_before_lost"] = []
    player["last_lost_known_tiles"] = {}
    player["known_players"] = {}
    player["known_open_edges"] = []
    player["known_broken_walls"] = []
    player["known_wall_edges"] = []
    player["visited_tiles"] = [f"{x},{y}"]
    player["lost_known_tiles"] = {}
    player["lost_manual_tiles"] = {}
    player["lost_manual_wall_edges"] = []
    player["lost_known_players"] = {}
    player["lost_known_open_edges"] = []
    player["lost_known_broken_walls"] = []
    player["lost_known_wall_edges"] = []
    player["lost_river_players"] = {}
    player["lost_kind"] = None
    player["map_fusion_blocked_until_turn"] = 0
    player["in_river"] = False
    player["lost_exit_visible_position"] = None
    player["spawn_effect_pending"] = False

    set_player_message(player, "Spawn selected. Your starting tile will be revealed when the game begins.")
    log(f"{player['name']} chose a spawn tile.")
    emit_full_state()


@socketio.on("player_set_map_note")
def player_set_map_note(data):
    """Let a player mark a personal map guess without changing the board."""
    if request.sid not in GAME["players"]:
        emit("error_message", {"message": "Player not found."})
        return
    if not GAME["game_started"]:
        emit("error_message", {"message": "Map notes are available after the game starts."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
    except (KeyError, TypeError, ValueError):
        emit("error_message", {"message": "Invalid map-note coordinates."})
        return

    tile = data.get("tile", "")
    if tile not in TILE_TYPES and tile != "":
        emit("error_message", {"message": "Invalid map-note tile."})
        return

    player = GAME["players"][request.sid]
    key = f"{x},{y}"
    if player["lost"]:
        if not (-100 <= x <= 100 and -100 <= y <= 100):
            emit("error_message", {"message": "That relative map square is too far away."})
            return
        known_tiles = player["lost_known_tiles"]
        manual_tiles = player["lost_manual_tiles"]
    else:
        if not in_bounds(x, y):
            emit("error_message", {"message": "Map-note coordinates are out of bounds."})
            return
        known_tiles = player["known_tiles"]
        manual_tiles = player["manual_tiles"]

    if key in known_tiles:
        emit("error_message", {"message": "That square is already confirmed on your map."})
        return

    if tile:
        manual_tiles[key] = tile
        set_player_message(player, f"Map note: marked {tile} at {x},{y} as an unconfirmed guess.", shared=False)
    else:
        manual_tiles.pop(key, None)
        set_player_message(player, f"Map note cleared at {x},{y}.", shared=False)
    emit_full_state()


@socketio.on("player_toggle_map_wall_note")
def player_toggle_map_wall_note(data):
    """Toggle a private guessed wall edge without using a turn."""
    if request.sid not in GAME["players"]:
        emit("error_message", {"message": "Player not found."})
        return
    if not GAME["game_started"]:
        emit("error_message", {"message": "Map notes are available after the game starts."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
    except (KeyError, TypeError, ValueError):
        emit("error_message", {"message": "Invalid wall-note coordinates."})
        return
    direction = data.get("direction")
    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid wall-note direction."})
        return

    player = GAME["players"][request.sid]
    dx, dy = DIRECTIONS[direction]
    other_pos = (x + dx, y + dy)
    if player["lost"]:
        if not (-100 <= x <= 100 and -100 <= y <= 100):
            emit("error_message", {"message": "That relative map square is too far away."})
            return
        known_edges = (
            player["lost_known_open_edges"]
            + player["lost_known_broken_walls"]
            + player["lost_known_wall_edges"]
        )
        manual_edges = player["lost_manual_wall_edges"]
    else:
        if not in_bounds(x, y) or not in_bounds(*other_pos):
            emit("error_message", {"message": "Wall guesses must be between two board squares."})
            return
        known_edges = (
            player["known_open_edges"]
            + player["known_broken_walls"]
            + player["known_wall_edges"]
        )
        manual_edges = player["manual_wall_edges"]

    edge = serialize_edge((x, y), other_pos)
    if edge in known_edges:
        emit("error_message", {"message": "That edge is already confirmed on your map."})
        return
    if edge in manual_edges:
        manual_edges.remove(edge)
        set_player_message(player, f"Map note: cleared wall guess {direction} of {x},{y}.", shared=False)
    else:
        manual_edges.append(edge)
        set_player_message(player, f"Map note: guessed a wall {direction} of {x},{y}.", shared=False)
    emit_full_state()


@socketio.on("player_move")
def player_move(data):
    ok, msg = validate_turn_action()
    if not ok:
        emit("error_message", {"message": msg})
        return

    direction = data.get("direction")
    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid direction."})
        return

    player = GAME["players"][request.sid]
    x, y = player["x"], player["y"]

    if wall_blocks(x, y, direction):
        if player["lost"]:
            dx, dy = DIRECTIONS[direction]
            remember_lost_edge(player, "lost_known_wall_edges", (x, y), (x + dx, y + dy))
        elif not is_outer_wall(x, y, direction):
            dx, dy = DIRECTIONS[direction]
            nx, ny = x + dx, y + dy
            if in_bounds(nx, ny):
                remember_wall_edge(player, (x, y), (nx, ny))
        set_player_message(player, "You hit a wall and stayed in place. Turn ended.")
        log(f"{player['name']} hit a wall while moving {direction}.")
        emit_full_state()
        end_turn()
        return

    dx, dy = DIRECTIONS[direction]
    new_pos = (x + dx, y + dy)

    was_lost = player["lost"]
    if not was_lost:
        remember_open_edge(player, (x, y), new_pos)
    player["x"] = new_pos[0]
    player["y"] = new_pos[1]
    if was_lost:
        player["lost_relative_x"] += dx
        player["lost_relative_y"] += dy
        remember_lost_edge(player, "lost_known_open_edges", (x, y), new_pos)
        remember_visited_tile(player, new_pos)
        remember_lost_tile(player, new_pos, "stepped onto")
    else:
        remember_visited_tile(player, new_pos)
    log(f"{player['name']} moved {direction}.")

    result = apply_tile_effect(player)

    if result == "game_over":
        emit_full_state()
        return

    if result == "pending_black_hole":
        emit_full_state()
        return

    if result == "dead":
        emit_full_state()
        end_turn()
        return

    continuing_river = (
        player.get("in_river")
        and GAME["board"][(player["x"], player["y"])] in {"river", "river_start"}
    )
    # A player's own birth tile always ends lost state, including while their
    # river-continuation tag is active on a river square.  Do not run the
    # general birth-tile visitor message while continuing in the river: it
    # would replace the river result when this square happens to be another
    # player's birth tile.
    is_own_birth_tile = (
        player["x"] == player["birth_x"]
        and player["y"] == player["birth_y"]
    )
    recovered_at_birth = False
    if continuing_river and player["lost"] and is_own_birth_tile:
        recovered_at_birth = check_birth_spot_discovery(player)
    if not continuing_river:
        recovered_at_birth = check_birth_spot_discovery(player)
        if not recovered_at_birth:
            check_previously_known_recovery(player)
        announce_players_on_tile(player)
    activate_map_fusion(player)
    for other in list(GAME["players"].values()):
        if other["sid"] != player["sid"] and other["alive"] and other["lost"] and (other["x"], other["y"]) == (player["x"], player["y"]):
            activate_map_fusion(other)
    refresh_known_player_positions()

    emit_full_state()
    end_turn()


@socketio.on("player_shoot")
def player_shoot(data):
    ok, msg = validate_turn_action()
    if not ok:
        emit("error_message", {"message": msg})
        return

    direction = data.get("direction")
    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid direction."})
        return

    shooter = GAME["players"][request.sid]
    if shooter["bullets"] <= 0:
        emit("error_message", {"message": "You have no bullets."})
        return

    shooter["bullets"] -= 1

    x, y = shooter["x"], shooter["y"]
    dx, dy = DIRECTIONS[direction]
    hit_targets = []

    while True:
        if wall_blocks(x, y, direction):
            if not is_outer_wall(x, y, direction):
                nx, ny = x + dx, y + dy
                if in_bounds(nx, ny):
                    if shooter["lost"]:
                        remember_lost_edge(shooter, "lost_known_wall_edges", (x, y), (nx, ny))
                    else:
                        remember_wall_edge(shooter, (x, y), (nx, ny))
            break

        x += dx
        y += dy
        if not in_bounds(x, y):
            break

        targets_here = []
        for other in GAME["players"].values():
            if not other["alive"]:
                continue
            if other["sid"] == shooter["sid"]:
                continue
            if other["x"] == x and other["y"] == y:
                targets_here.append(other)

        if targets_here:
            hit_targets = targets_here
            break

    if not hit_targets:
        set_player_message(shooter, "Your bullet hit nothing.")
        log(f"{shooter['name']} shot {direction} and hit nothing.")
        emit_full_state()
        end_turn()
        return

    set_player_message(shooter, f"You hit {', '.join(p['name'] for p in hit_targets)}.")
    # Resolve the whole impacted square before checking the winner/turn order.
    for hit_target in hit_targets:
        hit_target["injuries"] += 1
        set_player_message(hit_target, f"You were shot by {shooter['name']}.")
        log(f"{shooter['name']} shot {hit_target['name']}.")
        check_death(hit_target, "Killed by a bullet.", check_winner=False)
    check_last_player_win()
    order = alive_player_sids_in_order()
    if shooter['sid'] in order:
        GAME['current_turn_index'] = order.index(shooter['sid'])

    emit_full_state()
    end_turn()


@socketio.on("player_bomb")
def player_bomb(data):
    ok, msg = validate_turn_action()
    if not ok:
        emit("error_message", {"message": msg})
        return

    direction = data.get("direction")
    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid direction."})
        return

    player = GAME["players"][request.sid]
    if player["bombs"] <= 0:
        emit("error_message", {"message": "You have no bombs."})
        return

    player["bombs"] -= 1
    x, y = player["x"], player["y"]

    if is_outer_wall(x, y, direction):
        if player["lost"]:
            remember_lost_outer_wall_bomb(player, direction)
            if not check_lost_map_completion(player):
                edge_name = {
                    "up": "north",
                    "down": "south",
                    "left": "west",
                    "right": "east",
                }[direction]
                set_player_message(player, f"The wall did not explode. You found the {edge_name} outer edge.")
        else:
            set_player_message(player, "The wall did not explode.")
        log(f"{player['name']} tried to bomb an outer wall.")
        emit_full_state()
        end_turn()
        return

    dx, dy = DIRECTIONS[direction]
    nx, ny = x + dx, y + dy
    ek = edge_key((x, y), (nx, ny))

    if ek in GAME["inner_walls"]:
        GAME["inner_walls"].remove(ek)
        GAME["broken_walls"].add(ek)
        if player["lost"]:
            remember_lost_edge(player, "lost_known_broken_walls", (x, y), (nx, ny))
        else:
            remember_broken_wall(player, (x, y), (nx, ny))
        set_player_message(player, "The wall exploded.")
        log(f"{player['name']} destroyed an inner wall.")
    else:
        set_player_message(player, "There was no wall there.")
        log(f"{player['name']} used a bomb, but there was no wall.")

    emit_full_state()
    end_turn()


@socketio.on("player_flashlight")
def player_flashlight(data):
    ok, msg = validate_turn_action()
    if not ok:
        emit("error_message", {"message": msg})
        return

    direction = data.get("direction")
    if direction not in DIRECTIONS:
        emit("error_message", {"message": "Invalid direction."})
        return

    player = GAME["players"][request.sid]
    if not (player["items"]["flashlight"] and player["items"]["batteries"]):
        emit("error_message", {"message": "You need both flashlight and batteries."})
        return

    was_lost = player["lost"]
    revealed = reveal_line(player, direction)
    seen_tiles = [effective_tile_at(pos).replace("used_", "used ") for pos in revealed]
    seen_description = ", ".join(seen_tiles)
    if was_lost and not player["lost"]:
        recovery_message = player["last_message"]
        set_player_message(
            player,
            f"Flashlight looked {direction} and saw: {seen_description}. {recovery_message}",
        )
    elif revealed:
        set_player_message(
            player,
            f"Flashlight looked {direction} and saw {len(revealed)} tile(s): {seen_description}.",
        )
    else:
        set_player_message(player, f"Flashlight looked {direction} but a wall blocked the beam.")

    log(f"{player['name']} used flashlight {direction}.")
    emit_full_state()
    end_turn()


@socketio.on("manager_resolve_black_hole")
def manager_resolve_black_hole(data):
    if request.sid != MANAGER_SID:
        emit("error_message", {"message": "Only the manager can resolve black hole placement."})
        return

    if GAME["pending_black_hole"] is None:
        emit("error_message", {"message": "No pending black hole."})
        return

    try:
        x = int(data["x"])
        y = int(data["y"])
    except Exception:
        emit("error_message", {"message": "Invalid coordinates."})
        return

    if not in_bounds(x, y):
        emit("error_message", {"message": "Coordinates out of bounds."})
        return

    if GAME["board"][(x, y)] != "empty":
        emit("error_message", {"message": "Black hole destination must be an empty tile."})
        return

    player_sid = GAME["pending_black_hole"]["player_sid"]
    if player_sid not in GAME["players"]:
        GAME["pending_black_hole"] = None
        emit_full_state()
        return

    player = GAME["players"][player_sid]
    enter_lost_state(player, "black_hole")
    player["x"] = x
    player["y"] = y
    start_lost_relative_map(player)

    set_player_message(player, "You are lost after the black hole.")
    log(f"Manager placed {player['name']} after black hole.")

    GAME["pending_black_hole"] = None
    check_birth_spot_discovery(player)
    check_previously_known_recovery(player)
    announce_players_on_tile(player)
    refresh_known_player_positions()
    emit_full_state()
    end_turn()


if __name__ == "__main__":
    log("Server started.")
    socketio.run(app, host="0.0.0.0", port=10000)
